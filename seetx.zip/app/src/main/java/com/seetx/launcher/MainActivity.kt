package com.seetx.launcher

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.os.*
import android.view.*
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh

class MainActivity : Activity() {
    class G(val pkg: String, val name: String, val bmp: Bitmap, val color: Int)
    private lateinit var bg: ThemeBg
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var row: LinearLayout
    private lateinit var hs: HorizontalScrollView
    private lateinit var layer: FrameLayout
    private lateinit var layerIcon: ImageView
    private lateinit var play: TextView
    private var games = listOf<G>()
    private var sel = 0
    private var sp: SoundPool? = null
    private var tapId = 0
    private var introMp: MediaPlayer? = null
    private val prefs by lazy { getSharedPreferences("seetx", 0) }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val RED = 0xFFE53935.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val logo = BitmapFactory.decodeResource(resources, R.drawable.logo)
        val root = FrameLayout(this); root.setBackgroundColor(Color.BLACK)
        bg = ThemeBg(this); root.addView(bg, MP, MP)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), dp(38), dp(22), 0) }
        top.addView(ImageView(this).apply {
            setImageBitmap(logo); background = GradientDrawable().apply { cornerRadius = dp(10).toFloat() }; clipToOutline = true
        }, dp(36), dp(36))
        top.addView(TextView(this).apply {
            text = "SEETX"; textSize = 15f; typeface = Typeface.create("sans-serif", Typeface.BOLD); letterSpacing = .3f
            setTextColor(Color.WHITE); setPadding(dp(10), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, WC, 1f))
        top.addView(TextClock(this).apply { typeface = Typeface.create("sans-serif", Typeface.NORMAL); format12Hour = "hh:mm a"; format24Hour = "HH:mm"; textSize = 15f; setTextColor(0xCCFFFFFF.toInt()) })
        root.addView(top, MP, WC)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), 0, 0, dp(30)); clipChildren = false }
        title = TextView(this).apply { textSize = 36f; typeface = Typeface.create("sans-serif", Typeface.BOLD); letterSpacing = .04f; setTextColor(Color.WHITE) }
        sub = TextView(this).apply { typeface = Typeface.create("sans-serif", Typeface.NORMAL); textSize = 12f; letterSpacing = .25f; setTextColor(0xAAFFFFFF.toInt()) }
        play = TextView(this).apply {
            text = "▶  PLAY"; textSize = 15f; typeface = Typeface.create("sans-serif", Typeface.BOLD); letterSpacing = .2f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(42), dp(13), dp(42), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(RED, dark(RED))).apply { cornerRadius = dp(30).toFloat() }
            setOnClickListener { launch() }
        }
        hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; clipChildren = false }
        row = LinearLayout(this).apply { setPadding(dp(16), dp(6), dp(16), dp(6)); clipChildren = false }
        hs.addView(row)
        col.addView(title); col.addView(sub)
        col.addView(play, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(16); bottomMargin = dp(8) })
        col.addView(hs, MP, WC)
        root.addView(col, FrameLayout.LayoutParams(MP, WC, Gravity.BOTTOM))
        layer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.BLACK) }
        layerIcon = ImageView(this)
        layer.addView(layerIcon, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        root.addView(layer, MP, MP)
        setContentView(root)
        sp = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build()).build()
        tapId = sp!!.load(this, R.raw.tap, 1)
        if (b == null) splash(root, logo)
    }

    override fun onResume() { super.onResume(); layer.visibility = View.GONE; refresh() }
    override fun onBackPressed() {}

    override fun onWindowFocusChanged(h: Boolean) {
        super.onWindowFocusChanged(h)
        if (!h) return
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { it.hide(WindowInsets.Type.systemBars()); it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun tap() { sp?.play(tapId, 1f, 1f, 1, 0, 1f) }

    override fun onDestroy() {
        super.onDestroy()
        try { introMp?.release(); sp?.release() } catch (e: Exception) {}
    }

    private fun splash(root: FrameLayout, logo: Bitmap) {
        val v = Intro(this, logo)
        v.isClickable = true
        root.addView(v, MP, MP)
        val end = {
            try { introMp?.stop(); introMp?.release() } catch (e: Exception) {}
            introMp = null
            v.animate().alpha(0f).setDuration(500).withEndAction { root.removeView(v) }.start()
        }
        v.done = { end() }
        v.setOnClickListener { v.done = null; end() }
        introMp = try { MediaPlayer.create(this, R.raw.intro) } catch (e: Exception) { null }
        try { introMp?.start() } catch (e: Exception) {}
        v.begin()
    }

    private fun dark(c: Int): Int {
        val hsv = FloatArray(3); Color.colorToHSV(c, hsv); hsv[2] *= .55f; return Color.HSVToColor(hsv)
    }

    private fun accent(b: Bitmap): Int {
        val s = Bitmap.createScaledBitmap(b, 24, 24, true)
        val hsv = FloatArray(3); val w = FloatArray(12); val hs = FloatArray(12)
        for (x in 0 until 24) for (y in 0 until 24) {
            Color.colorToHSV(s.getPixel(x, y), hsv)
            val k = (hsv[0] / 30f).toInt().coerceIn(0, 11); val wt = hsv[1] * hsv[2] * hsv[2]
            w[k] += wt; hs[k] += wt * hsv[0]
        }
        var best = 0
        for (i in 1 until 12) if (w[i] > w[best]) best = i
        return if (w[best] < 1f) RED else Color.HSVToColor(floatArrayOf(hs[best] / w[best], .85f, .95f))
    }

    private fun loadGames(): List<G> {
        val pm = packageManager
        val manual = prefs.getStringSet("m", setOf())!!
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0).mapNotNull { r ->
            val ai = r.activityInfo.applicationInfo; val p = ai.packageName
            @Suppress("DEPRECATION")
            val game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || p in manual
            if (p == packageName || !game) null else {
                val bm = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
                val c = Canvas(bm); c.drawColor(Color.BLACK)
                val d = r.loadIcon(pm); d.setBounds(0, 0, 192, 192); d.draw(c)
                G(p, r.loadLabel(pm).toString(), bm, accent(bm))
            }
        }.distinctBy { it.pkg }.sortedBy { it.name.lowercase() }
    }

    private fun box(): FrameLayout = FrameLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(100), dp(100)).apply { setMargins(dp(8), dp(18), dp(8), dp(18)) }
        background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(0x22FFFFFF); setStroke(dp(1), 0x33FFFFFF) }
        clipToOutline = true
    }

    private fun refresh() {
        games = loadGames(); row.removeAllViews()
        games.forEachIndexed { i, g ->
            val f = box()
            f.addView(ImageView(this).apply { setImageBitmap(g.bmp) }, MP, MP)
            f.setOnClickListener { if (sel == i) launch() else select(i, true) }
            row.addView(f)
        }
        val add = box(); add.addView(TextView(this).apply { text = "+"; textSize = 36f; gravity = Gravity.CENTER; setTextColor(0xCCFFFFFF.toInt()) }, MP, MP)
        add.setOnClickListener { tap(); picker() }
        row.addView(add)
        select(if (sel < games.size) sel else 0, false)
    }

    private fun select(i: Int, snd: Boolean) {
        if (games.isEmpty()) { title.text = "NO GAMES FOUND"; sub.text = "NEECHE + DABAKE GAMES ADD KARO"; bg.setTheme(null, RED); return }
        sel = i; val g = games[i]
        if (snd) tap()
        title.text = g.name; title.setShadowLayer(10f, 0f, 3f, 0xAA000000.toInt()); sub.text = "READY TO PLAY"
        bg.setTheme(g.bmp, g.color)
        (play.background as GradientDrawable).colors = intArrayOf(g.color, dark(g.color))
        for (k in games.indices) {
            val t = row.getChildAt(k); val on = k == i; val sc = if (on) 1.14f else 1f
            t.animate().scaleX(sc).scaleY(sc).setDuration(200).start()
            (t.background as GradientDrawable).setStroke(dp(if (on) 2 else 1), if (on) g.color else 0x33FFFFFF)
        }
        val t = row.getChildAt(i); hs.post { hs.smoothScrollTo(t.left - (hs.width - t.width) / 2, 0) }
    }

    private fun picker() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }
        val m = prefs.getStringSet("m", setOf())!!.toMutableSet()
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val on = BooleanArray(apps.size) { apps[it].activityInfo.packageName in m }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Games chuno")
            .setMultiChoiceItems(names, on) { _, i, c -> val p = apps[i].activityInfo.packageName; if (c) m.add(p) else m.remove(p) }
            .setPositiveButton("OK") { _, _ -> prefs.edit().putStringSet("m", m).apply(); refresh() }.show()
    }

    private fun launch() {
        if (games.isEmpty()) return
        val g = games[sel]; val li = packageManager.getLaunchIntentForPackage(g.pkg) ?: return
        tap()
        layerIcon.setImageBitmap(g.bmp); layerIcon.scaleX = .5f; layerIcon.scaleY = .5f; layerIcon.alpha = 0f
        layer.alpha = 0f; layer.visibility = View.VISIBLE
        layer.animate().alpha(1f).setDuration(400).start()
        layerIcon.animate().alpha(1f).scaleX(1.6f).scaleY(1.6f).setDuration(700).start()
        Handler(Looper.getMainLooper()).postDelayed({ startActivity(li); overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out) }, 650)
    }
}

private class ThemeBg(c: android.content.Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var cur: Bitmap? = null
    private var prev: Bitmap? = null
    private var fade = 1f
    private var col = 0xFFE53935.toInt()
    fun setTheme(bm: Bitmap?, c: Int) {
        prev = cur
        cur = bm?.let { Bitmap.createScaledBitmap(it, 64, 64, true) }
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            addUpdateListener { fade = it.animatedValue as Float; invalidate() }
            start()
        }
        ValueAnimator.ofObject(ArgbEvaluator(), col, c).apply { duration = 700; addUpdateListener { col = it.animatedValue as Int }; start() }
    }
    private fun art(cv: Canvas, b: Bitmap, a: Int) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = maxOf(w / b.width, h / b.height) * 1.05f
        val bw = b.width * s; val bh = b.height * s
        p.alpha = a
        cv.drawBitmap(b, null, RectF((w - bw) / 2, (h - bh) / 2, (w + bw) / 2, (h + bh) / 2), p)
    }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = Color.red(col); val g = Color.green(col); val b = Color.blue(col)
        cv.drawColor(0xFF07080D.toInt())
        prev?.let { art(cv, it, 255) }
        cur?.let { art(cv, it, (255 * fade).toInt()) }
        p.alpha = 255
        if (cur == null) {
            p.shader = RadialGradient(w * .8f, h * .3f, w * .7f, intArrayOf(Color.argb(110, r, g, b), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, h, p); p.shader = null
        }
        p.color = Color.argb(60, r, g, b); cv.drawRect(0f, 0f, w, h, p)
        p.color = Color.argb(70, 0, 0, 0); cv.drawRect(0f, 0f, w, h, p)
        p.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(Color.argb(235, 7, 8, 13), Color.argb(150, 7, 8, 13), Color.argb(30, 7, 8, 13)), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p)
        p.shader = LinearGradient(0f, h * .4f, 0f, h, intArrayOf(Color.TRANSPARENT, Color.argb(225, 0, 0, 0)), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null
    }
}

private class Intro(c: android.content.Context, private val logo: Bitmap) : View(c) {
    private var t0 = 0L
    private var started = false
    var done: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rnd = java.util.Random(3)
    private val px = FloatArray(30) { rnd.nextFloat() }
    private val ps = FloatArray(30) { .06f + rnd.nextFloat() * .12f }
    private val pz = FloatArray(30) { 1.5f + rnd.nextFloat() * 2.5f }
    fun begin() { t0 = System.nanoTime(); started = true; invalidate() }
    private fun cl(v: Float) = v.coerceIn(0f, 1f)
    private fun ease(v: Float) = 1 - (1 - v) * (1 - v) * (1 - v)

    override fun onDraw(cv: Canvas) {
        cv.drawColor(0xFF06070B.toInt())
        if (!started) return
        val t = (System.nanoTime() - t0) / 1e9f
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2 - h * .03f
        val sz = minOf(w * .42f, h * .58f)
        val T = 2.75f
        val sa = cl((t - .4f) / 1.6f); val sw = w * .09f; val sk = h * .7f
        var x = -sk; var k = 0
        while (x < w) {
            path.reset(); path.moveTo(x, h); path.lineTo(x + sw, h); path.lineTo(x + sw + sk, 0f); path.lineTo(x + sk, 0f); path.close()
            p.color = if (k % 2 == 0) Color.argb((34 * sa).toInt(), 229, 57, 53) else Color.argb((12 * sa).toInt(), 255, 255, 255)
            cv.drawPath(path, p); x += w * .26f; k++
        }
        val ga = if (t < T) cl((t - 1.2f) / 1.55f) * .55f else .55f + .45f * cl((t - T) / .6f)
        p.shader = RadialGradient(cx, cy, w * .6f, intArrayOf(Color.argb((80 * ga).toInt(), 229, 57, 53), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null
        p.color = 0xFFFF5A4F.toInt()
        val ea = cl((t - .5f) / 1.5f)
        for (i in px.indices) {
            val y = h - ((t * ps[i] + i * .137f) % 1f) * h
            p.alpha = (110 * ea * (y / h)).toInt().coerceIn(0, 255)
            cv.drawCircle(px[i] * w, y, pz[i], p)
        }
        val lu = cl((t - .3f) / .5f); val la = 1f - cl((t - .8f) / .4f)
        if (lu > 0f && la > 0f) {
            val lw = w * .9f * ease(lu)
            p.shader = LinearGradient(0f, cy - 30f, 0f, cy + 30f, intArrayOf(Color.TRANSPARENT, Color.argb((110 * la).toInt(), 229, 57, 53), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            cv.drawRect(cx - lw / 2, cy - 30f, cx + lw / 2, cy + 30f, p); p.shader = null
            p.color = Color.argb((230 * la).toInt(), 255, 255, 255)
            cv.drawRect(cx - lw / 2, cy - 1.5f, cx + lw / 2, cy + 1.5f, p)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f
        for (j in 0..1) {
            val st = 1.2f + j * .3f; val u = cl((t - st) / (T - st))
            if (u > 0f && u < 1f) {
                p.color = Color.argb((150 * sin(u * 3.14159f)).toInt(), 255, 90, 80)
                cv.drawCircle(cx, cy, sz * (1.8f - 1.25f * u * u), p)
            }
        }
        val ru = cl((t - T) / .8f)
        if (t >= T && ru < 1f) {
            p.strokeWidth = 3f; p.color = Color.argb((160 * (1 - ru)).toInt(), 255, 90, 80)
            cv.drawCircle(cx, cy, sz * (.5f + .7f * ease(ru)), p)
        }
        p.style = Paint.Style.FILL
        if (t >= T) {
            val u = cl((t - T) / .6f)
            val sc = (.82f + .18f * ease(u)) * (1f + .03f * cl((t - 3.3f) / 1.7f))
            val dst = RectF(-sz / 2, -sz / 2, sz / 2, sz / 2)
            cv.save(); cv.translate(cx, cy); cv.scale(sc, sc)
            p.color = Color.WHITE; p.alpha = (255 * cl(u * 3f)).toInt()
            cv.drawBitmap(logo, null, dst, p)
            val st = (t - 3.3f) / .7f
            if (st in 0f..1f) {
                cv.save(); cv.clipRect(dst)
                val bx = -sz + st * sz * 2f
                p.color = Color.WHITE
                p.shader = LinearGradient(bx, -sz / 2, bx + sz * .35f, sz / 2, intArrayOf(Color.TRANSPARENT, 0x55FFFFFF, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
                cv.drawRect(dst, p); p.shader = null
                cv.restore()
            }
            cv.restore()
        }
        val fa = if (t >= T) 1f - cl((t - T) / .3f) else 0f
        if (fa > 0f) { p.color = Color.argb((70 * fa).toInt(), 255, 120, 110); cv.drawRect(0f, 0f, w, h, p) }
        val ta = cl((t - 3.2f) / .8f)
        if (ta > 0f) {
            val ty = cy + sz / 2 + h * .11f
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif", Typeface.BOLD); p.textSize = h * .06f
            p.letterSpacing = .5f - .25f * ease(ta)
            p.color = Color.argb((255 * ta).toInt(), 255, 255, 255)
            cv.drawText("WELCOME", cx, ty, p); p.letterSpacing = 0f
            val lw = h * .1f * ease(ta)
            p.color = Color.argb((255 * ta).toInt(), 229, 57, 53)
            cv.drawRect(cx - lw, ty + 18f, cx + lw, ty + 22f, p)
        }
        if (t < 5f) postInvalidateOnAnimation() else { val d = done; done = null; d?.invoke() }
    }
}
