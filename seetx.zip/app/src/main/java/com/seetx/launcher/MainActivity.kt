package com.seetx.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.os.*
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.*
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    class G(val pkg: String, val name: String, val bmp: Bitmap, val color: Int)
    private lateinit var bg: ImageView
    private lateinit var shade: View
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var row: LinearLayout
    private lateinit var hs: HorizontalScrollView
    private lateinit var layer: FrameLayout
    private lateinit var layerIcon: ImageView
    private lateinit var play: TextView
    private var games = listOf<G>()
    private var sel = 0
    private val prefs by lazy { getSharedPreferences("seetx", 0) }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val CY = 0xFF00E5FF.toInt()
    private val PK = 0xFFFF2BD6.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this); root.setBackgroundColor(Color.BLACK)
        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0f; scaleX = 2.2f; scaleY = 2.2f
            if (Build.VERSION.SDK_INT >= 31) setRenderEffect(RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.CLAMP)) }
        shade = View(this)
        root.addView(bg, MP, MP); root.addView(shade, MP, MP)
        val head = TextView(this).apply { text = "SEETX"; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = .35f
            setTextColor(CY); setShadowLayer(24f, 0f, 0f, CY); setPadding(dp(24), dp(36), 0, 0) }
        root.addView(head, WC, WC)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), 0, 0, dp(30)) }
        title = TextView(this).apply { textSize = 34f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = .06f; setTextColor(Color.WHITE) }
        sub = TextView(this).apply { textSize = 14f; setTextColor(0xAAFFFFFF.toInt()) }
        play = TextView(this).apply { text = "▶  PLAY"; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = .15f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(40), dp(14), dp(40), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(CY, PK)).apply { cornerRadius = dp(30).toFloat() }
            setOnClickListener { launch() } }
        hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        row = LinearLayout(this).apply { setPadding(dp(16), dp(6), dp(16), dp(6)); clipChildren = false }
        hs.clipChildren = false; col.clipChildren = false
        hs.addView(row)
        col.addView(title); col.addView(sub)
        col.addView(play, LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(14); bottomMargin = dp(10) })
        col.addView(hs, MP, WC)
        root.addView(col, FrameLayout.LayoutParams(MP, WC, Gravity.BOTTOM))
        layer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.BLACK) }
        layerIcon = ImageView(this)
        layer.addView(layerIcon, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        root.addView(layer, MP, MP)
        setContentView(root)
        if (b == null) splash(root)
    }

    override fun onResume() { super.onResume(); layer.visibility = View.GONE; refresh() }
    override fun onBackPressed() {}

    override fun onWindowFocusChanged(h: Boolean) {
        super.onWindowFocusChanged(h)
        if (!h) return
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { it.hide(WindowInsets.Type.systemBars()); it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun tone(f1: Double, f2: Double, ms: Int, vol: Double = .3) = thread {
        val sr = 22050; val n = sr * ms / 1000; val d = ShortArray(n); var ph = 0.0
        for (i in 0 until n) { val t = i.toDouble() / n; ph += 2 * PI * (f1 + (f2 - f1) * t) / sr; d[i] = (sin(ph) * (1 - t) * vol * 32767).toInt().toShort() }
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        at.write(d, 0, n); at.play(); Thread.sleep(ms + 150L); at.release()
    }

    private fun splash(root: FrameLayout) {
        val s = FrameLayout(this); s.setBackgroundColor(0xFF02030A.toInt()); s.isClickable = true
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_fg); scaleX = 0f; scaleY = 0f; rotation = -360f }
        s.addView(logo, FrameLayout.LayoutParams(dp(260), dp(260), Gravity.CENTER))
        val t = TextView(this).apply { text = "SEETX"; textSize = 30f; typeface = Typeface.DEFAULT_BOLD; letterSpacing = .4f; gravity = Gravity.CENTER
            setTextColor(CY); setShadowLayer(30f, 0f, 0f, PK); alpha = 0f }
        s.addView(t, FrameLayout.LayoutParams(MP, WC, Gravity.CENTER).apply { topMargin = dp(170) })
        root.addView(s, MP, MP)
        val h = Handler(Looper.getMainLooper())
        tone(200.0, 900.0, 1000, .2)
        listOf(523.0, 659.0, 784.0, 1047.0).forEachIndexed { k, f -> h.postDelayed({ tone(f, f, 350, .25) }, 400L + k * 130) }
        logo.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(900).setInterpolator(OvershootInterpolator()).start()
        t.animate().alpha(1f).setStartDelay(600).setDuration(700).start()
        s.animate().alpha(0f).setStartDelay(2300).setDuration(700).withEndAction { root.removeView(s) }.start()
    }

    private fun accent(b: Bitmap): Int {
        val p = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3); Color.colorToHSV(p, hsv); hsv[1] = maxOf(hsv[1], .7f); hsv[2] = 1f
        return Color.HSVToColor(hsv)
    }

    private fun loadGames(): List<G> {
        val pm = packageManager
        val manual = prefs.getStringSet("m", setOf())!!
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0).mapNotNull { r ->
            val ai = r.activityInfo.applicationInfo; val p = ai.packageName
            @Suppress("DEPRECATION")
            val game = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || p in manual
            if (p == packageName || !game) null else {
                val bm = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
                val c = Canvas(bm); c.drawColor(Color.BLACK)
                val d = r.loadIcon(pm); d.setBounds(0, 0, 192, 192); d.draw(c)
                G(p, r.loadLabel(pm).toString(), bm, accent(bm))
            }
        }.distinctBy { it.pkg }.sortedBy { it.name.lowercase() }
    }

    private fun box(): FrameLayout = FrameLayout(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(104), dp(104)).apply { setMargins(dp(8), dp(18), dp(8), dp(18)) }
        background = GradientDrawable().apply { cornerRadius = dp(26).toFloat(); setColor(0x33FFFFFF); setStroke(dp(2), 0x33FFFFFF) }
        clipToOutline = true
    }

    private fun refresh() {
        games = loadGames(); row.removeAllViews()
        games.forEachIndexed { i, g ->
            val f = box()
            f.addView(ImageView(this).apply { setImageBitmap(g.bmp) }, MP, MP)
            f.setOnClickListener { if (sel == i) launch() else select(i, true) }
            row.addView(f)
        }
        val add = box(); add.addView(TextView(this).apply { text = "+"; textSize = 40f; gravity = Gravity.CENTER; setTextColor(CY) }, MP, MP)
        add.setOnClickListener { tone(700.0, 1300.0, 80); picker() }
        row.addView(add)
        select(if (sel < games.size) sel else 0, false)
    }

    private fun select(i: Int, snd: Boolean) {
        if (games.isEmpty()) { title.text = "NO GAMES FOUND"; sub.text = "Neeche + dabake games add karo"; shade.setBackgroundColor(0xFF05060D.toInt()); return }
        sel = i; val g = games[i]
        if (snd) tone(700.0, 1300.0, 80)
        title.text = g.name.uppercase(); title.setShadowLayer(40f, 0f, 0f, g.color); sub.text = "Ready to play"
        bg.setImageBitmap(g.bmp); bg.animate().cancel(); bg.alpha = 0f; bg.animate().alpha(.6f).setDuration(600).start()
        shade.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(90, Color.red(g.color), Color.green(g.color), Color.blue(g.color)), Color.argb(235, 0, 0, 0)))
        (play.background as GradientDrawable).colors = intArrayOf(g.color, PK)
        for (k in games.indices) {
            val t = row.getChildAt(k); val on = k == i; val sc = if (on) 1.18f else 1f
            t.animate().scaleX(sc).scaleY(sc).setDuration(200).start()
            (t.background as GradientDrawable).setStroke(dp(if (on) 3 else 2), if (on) g.color else 0x33FFFFFF)
        }
        val t = row.getChildAt(i); hs.post { hs.smoothScrollTo(t.left - (hs.width - t.width) / 2, 0) }
    }

    private fun picker() {
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }.sortedBy { it.loadLabel(pm).toString().lowercase() }
        val m = prefs.getStringSet("m", setOf())!!.toMutableSet()
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val on = BooleanArray(apps.size) { apps[it].activityInfo.packageName in m }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Games chuno")
            .setMultiChoiceItems(names, on) { _, i, c -> val p = apps[i].activityInfo.packageName; if (c) m.add(p) else m.remove(p) }
            .setPositiveButton("OK") { _, _ -> prefs.edit().putStringSet("m", m).apply(); refresh() }.show()
    }

    private fun launch() {
        if (games.isEmpty()) return
        val g = games[sel]; val li = packageManager.getLaunchIntentForPackage(g.pkg) ?: return
        tone(150.0, 1800.0, 900, .35)
        layerIcon.setImageBitmap(g.bmp); layerIcon.scaleX = .4f; layerIcon.scaleY = .4f
        layer.alpha = 0f; layer.visibility = View.VISIBLE
        layer.animate().alpha(1f).setDuration(450).start()
        layerIcon.animate().scaleX(2.2f).scaleY(2.2f).setDuration(700).start()
        Handler(Looper.getMainLooper()).postDelayed({ startActivity(li); overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out) }, 650)
    }
}
