package com.seetx.launcher

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sin

class MainActivity : Activity() {
    class G(val pkg: String, val name: String, val bmp: Bitmap)
    class App(val pkg: String, val name: String, val icon: Drawable, val game: Boolean)

    private lateinit var root: FrameLayout
    private lateinit var cube: CubeBg
    private lateinit var strip: LinearLayout
    private lateinit var hs: HorizontalScrollView
    private lateinit var titleTv: TextView
    private lateinit var played: TextView
    private lateinit var moreBtn: TextView
    private lateinit var launchBtn: TextView
    private lateinit var layer: FrameLayout
    private lateinit var layerIcon: ImageView
    private lateinit var logoBmp: Bitmap
    private var games = listOf<G>()
    private var usageMap: Map<String, Long> = emptyMap()
    private var sel = 0
    private var perfTab = 0
    private var dlg: View? = null
    private var permRefresh: (() -> Unit)? = null
    private val pages = ArrayList<View>()
    private var sp: SoundPool? = null
    private var tapId = 0
    private var introMp: MediaPlayer? = null
    private val prefs by lazy { getSharedPreferences("seetx", 0) }
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val MODE_NAMES = arrayOf("Power saving mode", "Balanced mode", "Pro Gamer mode")
    private val MODE_DESC = arrayOf("Reduce power consumption to prolong your battery life.", "Intelligently balance performance and power consumption.", "Enhance device performance to deliver a professional gaming experience. This will increase your device's power consumption and temperature.")
    private val MODE_COLORS = intArrayOf(0xFF35C8FF.toInt(), 0xFF7ED321.toInt(), 0xFFFF5A00.toInt())
    private val GREY = 0xFF9A9A9A.toInt()
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun accent() = MODE_COLORS[prefs.getInt("ov_mode", 1)]
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    // ---------- helpers ----------
    private fun box(r: Int, c: Int, stroke: Int = 0, sc: Int = 0): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(c); if (stroke > 0) setStroke(dp(stroke), sc)
    }
    private fun lin(v: Boolean): LinearLayout = LinearLayout(this).apply { orientation = if (v) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
    private fun tv(t: String, sp: Float, c: Int, bold: Boolean = false, g: Int = Gravity.START): TextView = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); gravity = g
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun card(): LinearLayout = lin(true).apply { background = box(16, 0xFF1E1E1E.toInt()); setPadding(dp(2), dp(2), dp(2), dp(2)) }
    private fun line(): View = View(this).apply { setBackgroundColor(0x22FFFFFF) }
    private fun fmt(ms: Long): String { val m = ms / 60000; return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min" }
    private fun tap() { sp?.play(tapId, 1f, 1f, 1, 0, 1f) }
    private fun label(t: String): TextView = tv(t, 12f, accent(), true).apply { letterSpacing = .2f; setPadding(dp(4), dp(20), 0, dp(8)) }

    private fun sw(on: Boolean, ok: Boolean, change: (Boolean) -> Unit): Switch {
        val s = Switch(this); s.isChecked = on; s.isEnabled = ok
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(st, intArrayOf(Color.WHITE, 0xFFBBBBBB.toInt()))
        s.trackTintList = ColorStateList(st, intArrayOf(accent(), 0xFF555555.toInt()))
        s.setOnCheckedChangeListener { _, c -> change(c) }
        return s
    }

    private fun switchRow(t: String, d: String, on: Boolean, ok: Boolean, change: (Boolean) -> Unit): View {
        val r = lin(false); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(dp(16), dp(14), dp(16), dp(14))
        val c = lin(true); c.addView(tv(t, 15f, Color.WHITE)); c.addView(tv(d, 12f, GREY))
        if (!ok) c.addView(tv("System only - apps cannot change this", 11f, 0xFFB07A3A.toInt()))
        r.addView(c, LinearLayout.LayoutParams(0, WC, 1f))
        r.addView(sw(on, ok, change), LinearLayout.LayoutParams(WC, WC).apply { leftMargin = dp(12) })
        r.alpha = if (ok) 1f else .55f
        return r
    }

    private fun chips(opts: List<Pair<String, String>>, cur: Int, ok: Boolean, pick: (Int) -> Unit): View {
        val row = lin(false); row.setPadding(dp(12), dp(6), dp(12), dp(14))
        opts.forEachIndexed { i, o ->
            val c = lin(true); c.gravity = Gravity.CENTER; c.setPadding(dp(8), dp(12), dp(8), dp(12))
            c.background = if (i == cur) box(12, 0xFF1C1C1E.toInt(), 2, accent()) else box(12, 0xFF2A2A2A.toInt())
            c.addView(tv(o.first, 14f, if (i == cur) accent() else Color.WHITE, false, Gravity.CENTER))
            c.addView(tv(o.second, 11f, GREY, false, Gravity.CENTER))
            c.setOnClickListener { if (ok) pick(i) else toast("System only") }
            row.addView(c, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        row.alpha = if (ok) 1f else .55f
        return row
    }

    private fun slider(t: String): View {
        val c = lin(true); c.setPadding(dp(16), dp(14), dp(16), dp(10))
        c.addView(tv(t, 15f, Color.WHITE))
        val sb = SeekBar(this); sb.max = 4; sb.progress = 2; sb.isEnabled = false
        sb.progressTintList = ColorStateList.valueOf(accent()); sb.thumbTintList = ColorStateList.valueOf(accent())
        c.addView(sb, MP, WC)
        val l = lin(false)
        for (s in listOf("-2", "-1", "Default", "1", "2")) l.addView(tv(s, 11f, GREY, false, Gravity.CENTER), LinearLayout.LayoutParams(0, WC, 1f))
        c.addView(l, MP, WC)
        c.addView(tv("System only - apps cannot change this", 11f, 0xFFB07A3A.toInt()))
        c.alpha = .55f
        return c
    }

    // ---------- pages ----------
    private fun pageFrame(): FrameLayout = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isClickable = true }

    private fun push(v: View) {
        root.addView(v, MP, MP); pages.add(v)
        v.alpha = 0f; v.translationX = dp(30).toFloat(); v.animate().alpha(1f).translationX(0f).setDuration(220).start()
    }

    private fun pop() {
        if (pages.isEmpty()) return
        val v = pages.removeAt(pages.size - 1)
        v.animate().alpha(0f).translationX(dp(30).toFloat()).setDuration(160).withEndAction { root.removeView(v); refresh() }.start()
    }

    private fun header(t: String): LinearLayout {
        val h = lin(false); h.gravity = Gravity.CENTER_VERTICAL
        val b = tv("\u2190", 26f, Color.WHITE); b.setPadding(0, dp(4), dp(16), dp(4)); b.setOnClickListener { tap(); pop() }
        h.addView(b); h.addView(tv(t, 18f, Color.WHITE), LinearLayout.LayoutParams(0, WC, 1f))
        return h
    }

    private fun closeDlg() { dlg?.let { root.removeView(it) }; dlg = null }

    private fun confirm(title: String, msg: String, ok: String, go: () -> Unit) {
        closeDlg()
        val f = FrameLayout(this); f.isClickable = true
        val sc = View(this); sc.setBackgroundColor(0x99000000.toInt()); sc.setOnClickListener { closeDlg() }
        f.addView(sc, MP, MP)
        val c = lin(true); c.background = box(26, 0xFF1F1F1F.toInt()); c.setPadding(dp(22), dp(22), dp(22), dp(18))
        c.addView(tv(title, 18f, Color.WHITE, true, Gravity.CENTER))
        val m = tv(msg, 13f, 0xFFB0B0B0.toInt()); m.setPadding(0, dp(10), 0, dp(18)); c.addView(m)
        val b = lin(false)
        val cn = tv("Cancel", 15f, Color.WHITE, false, Gravity.CENTER); cn.setPadding(0, dp(13), 0, dp(13)); cn.background = box(24, 0xFF333333.toInt()); cn.setOnClickListener { tap(); closeDlg() }
        val okb = tv(ok, 15f, Color.BLACK, true, Gravity.CENTER); okb.setPadding(0, dp(13), 0, dp(13)); okb.background = box(24, accent()); okb.setOnClickListener { tap(); closeDlg(); go() }
        b.addView(cn, LinearLayout.LayoutParams(0, WC, 1f).apply { rightMargin = dp(8) }); b.addView(okb, LinearLayout.LayoutParams(0, WC, 1f))
        c.addView(b)
        val w = minOf(dp(460), resources.displayMetrics.widthPixels - dp(32))
        f.addView(c, FrameLayout.LayoutParams(w, WC, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(24) })
        root.addView(f, MP, MP); dlg = f
    }

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        logoBmp = BitmapFactory.decodeResource(resources, R.drawable.logo)
        root = FrameLayout(this); root.setBackgroundColor(Color.BLACK)
        cube = CubeBg(this); root.addView(cube, MP, MP)
        root.addView(buildHome(), MP, MP)
        layer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.BLACK) }
        layerIcon = ImageView(this)
        layer.addView(layerIcon, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        root.addView(layer, MP, MP)
        sp = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build()).build()
        tapId = sp!!.load(this, R.raw.tap, 1)
        setContentView(root)
        if (b == null) splash(root, logoBmp)
    }

    override fun onResume() {
        super.onResume(); layer.visibility = View.GONE
        stopService(Intent(this, GameOverlayService::class.java))
        permRefresh?.invoke(); refresh()
    }

    override fun onBackPressed() { if (dlg != null) closeDlg() else if (pages.isNotEmpty()) pop() }

    override fun onDestroy() {
        super.onDestroy()
        try { introMp?.release(); sp?.release() } catch (e: Exception) {}
    }

    override fun onWindowFocusChanged(h: Boolean) {
        super.onWindowFocusChanged(h)
        if (!h) return
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { it.hide(WindowInsets.Type.systemBars()); it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun splash(root: FrameLayout, logo: Bitmap) {
        val v = Intro(this, logo)
        root.addView(v, MP, MP)
        val end = {
            try { introMp?.stop(); introMp?.release() } catch (e: Exception) {}
            introMp = null
            v.animate().alpha(0f).setDuration(500).withEndAction { root.removeView(v) }.start()
        }
        v.setOnClickListener { if (v.ready()) { tap(); end() } }
        introMp = try { MediaPlayer.create(this, R.raw.intro) } catch (e: Exception) { null }
        try { introMp?.start() } catch (e: Exception) {}
        v.begin()
    }

    // ---------- home ----------
    private fun buildHome(): View {
        val col = lin(true); col.setPadding(dp(16), dp(34), dp(16), dp(20))
        val top = lin(false); top.gravity = Gravity.CENTER_VERTICAL
        val menu = tv("\u2630", 26f, Color.WHITE); menu.setPadding(dp(6), dp(6), dp(14), dp(6)); menu.setOnClickListener { tap(); showProfile() }
        top.addView(menu); top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val lg = ImageView(this); lg.setImageBitmap(logoBmp); lg.background = box(9, 0); lg.clipToOutline = true
        top.addView(lg, dp(32), dp(32))
        col.addView(top, MP, WC)
        hs = HorizontalScrollView(this); hs.isHorizontalScrollBarEnabled = false; hs.clipChildren = false
        strip = lin(false); strip.gravity = Gravity.CENTER_VERTICAL; strip.setPadding(0, dp(14), 0, dp(14)); strip.clipChildren = false
        hs.addView(strip)
        col.addView(hs, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(6) })
        val info = lin(false)
        val tc = lin(true)
        titleTv = tv("", 30f, Color.WHITE, true); played = tv("", 13f, 0xFFB0B0B0.toInt())
        tc.addView(titleTv); tc.addView(played)
        info.addView(tc, LinearLayout.LayoutParams(0, WC, 1f))
        moreBtn = tv("\u22EE", 22f, Color.WHITE, true, Gravity.CENTER)
        moreBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x33FFFFFF) }
        moreBtn.setOnClickListener { tap(); showMenu(moreBtn) }
        info.addView(moreBtn, dp(40), dp(40))
        col.addView(info, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(18) })
        col.addView(View(this), LinearLayout.LayoutParams(MP, 0, 1f))
        val bottom = lin(false); bottom.gravity = Gravity.CENTER_VERTICAL
        val perf = lin(true); perf.gravity = Gravity.CENTER_HORIZONTAL
        perf.addView(tv("\u25D4", 22f, Color.WHITE, false, Gravity.CENTER)); perf.addView(tv("Performance settings", 10f, 0xFFB0B0B0.toInt(), false, Gravity.CENTER))
        perf.setOnClickListener { tap(); showPerf() }
        launchBtn = tv("Launch", 17f, accent(), false, Gravity.CENTER); launchBtn.setPadding(0, dp(16), 0, dp(16))
        launchBtn.setOnClickListener { launch() }
        bottom.addView(perf, LinearLayout.LayoutParams(dp(78), WC)); bottom.addView(launchBtn, LinearLayout.LayoutParams(0, WC, 1f).apply { leftMargin = dp(10) })
        col.addView(bottom, MP, WC)
        return col
    }

    private fun applyAccent() {
        val a = accent(); cube.setAccent(a); launchBtn.setTextColor(a)
        launchBtn.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(al(a, 110), al(a, 40))).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), al(a, 170)) }
    }

    private fun queryApps(): List<App> {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).mapNotNull { r ->
            val ai = r.activityInfo.applicationInfo
            if (ai.packageName == packageName) null else {
                @Suppress("DEPRECATION")
                val g = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                App(ai.packageName, r.loadLabel(pm).toString(), r.loadIcon(pm), g)
            }
        }.distinctBy { it.pkg }.sortedBy { it.name.lowercase() }
    }

    private fun loadGames(): List<G> {
        val man = prefs.getStringSet("m", setOf())!!; val rm = prefs.getStringSet("rm", setOf())!!
        return queryApps().filter { (it.game || it.pkg in man) && it.pkg !in rm }.map {
            val bm = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
            val c = Canvas(bm); c.drawColor(Color.BLACK); it.icon.setBounds(0, 0, 192, 192); it.icon.draw(c)
            G(it.pkg, it.name, bm)
        }
    }

    private fun tile(content: View): RgbTile {
        val t = RgbTile(this, dp(14).toFloat(), dp(7).toFloat(), resources.displayMetrics.density)
        t.layoutParams = LinearLayout.LayoutParams(dp(66), dp(66)).apply { setMargins(dp(2), 0, dp(2), 0) }
        val inner = FrameLayout(this)
        inner.background = box(14, 0x22FFFFFF); inner.clipToOutline = true
        inner.addView(content, MP, MP)
        t.addView(inner, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        return t
    }

    private fun refresh() {
        usageMap = if (hasUsage()) usage30() else emptyMap()
        games = loadGames(); strip.removeAllViews()
        games.forEachIndexed { i, g ->
            val t = tile(ImageView(this).apply { setImageBitmap(g.bmp) })
            t.setOnClickListener { if (sel != i) select(i, true) }
            strip.addView(t)
        }
        val add = FrameLayout(this); add.background = box(14, 0xFF2A2A2A.toInt())
        add.addView(tv("+", 28f, Color.WHITE, false, Gravity.CENTER), MP, MP)
        add.setOnClickListener { tap(); showManage() }
        strip.addView(add, LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(8), 0, dp(8), 0) })
        applyAccent()
        select(if (sel < games.size) sel else 0, false)
    }

    private fun select(i: Int, snd: Boolean) {
        if (games.isEmpty()) { titleTv.text = "No games"; played.text = "Tap + to add games"; return }
        sel = i; val g = games[i]
        if (snd) tap()
        titleTv.text = g.name
        played.text = if (hasUsage()) "Played ${fmt(usageMap[g.pkg] ?: 0L)} in last 30 days" else "Played ${prefs.getInt("n_" + g.pkg, 0)} times via SeetX"
        for (k in games.indices) {
            val t = strip.getChildAt(k) as RgbTile; val on = k == i; val sc = if (on) 1.2f else 1f
            t.on = on; t.animate().scaleX(sc).scaleY(sc).setDuration(200).start()
        }
        val t = strip.getChildAt(i); hs.post { hs.smoothScrollTo(t.left - (hs.width - t.width) / 2, 0) }
    }

    private fun removeGame(pkg: String) {
        val rm = HashSet(prefs.getStringSet("rm", emptySet())!!); rm.add(pkg)
        val m = HashSet(prefs.getStringSet("m", emptySet())!!); m.remove(pkg)
        prefs.edit().putStringSet("rm", rm).putStringSet("m", m).apply()
        sel = 0; refresh()
    }

    private fun showMenu(anchor: View) {
        if (games.isEmpty()) return
        val g = games[sel]
        val c = lin(true); c.background = box(14, 0xFF2B2B2B.toInt()); c.setPadding(0, dp(8), 0, dp(8))
        val pw = PopupWindow(c, dp(230), WC, true)
        fun item(t: String, a: () -> Unit) {
            val v = tv(t, 15f, Color.WHITE); v.setPadding(dp(18), dp(12), dp(18), dp(12))
            v.setOnClickListener { pw.dismiss(); a() }; c.addView(v, MP, WC)
        }
        item("App info") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${g.pkg}"))) }
        item("Remove from SeetX") { removeGame(g.pkg) }
        item("Uninstall") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${g.pkg}"))) }
        pw.elevation = 20f
        pw.showAsDropDown(anchor, -dp(190), 0)
    }

    private fun launch() {
        if (games.isEmpty()) return
        val g = games[sel]; val li = packageManager.getLaunchIntentForPackage(g.pkg) ?: return
        tap()
        prefs.edit().putInt("n_all", prefs.getInt("n_all", 0) + 1).putInt("n_" + g.pkg, prefs.getInt("n_" + g.pkg, 0) + 1).apply()
        if (Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(Intent(this, GameOverlayService::class.java).putExtra("pkg", g.pkg).putExtra("name", g.name).putStringArrayListExtra("games", ArrayList(games.map { it.pkg })))
            } catch (e: Exception) {}
        } else Toast.makeText(this, "In-game panel: More settings > Permissions mein 'Display over other apps' ON karo", Toast.LENGTH_LONG).show()
        layerIcon.setImageBitmap(g.bmp); layerIcon.scaleX = .5f; layerIcon.scaleY = .5f; layerIcon.alpha = 0f
        layer.alpha = 0f; layer.visibility = View.VISIBLE
        layer.animate().alpha(1f).setDuration(400).start()
        layerIcon.animate().alpha(1f).scaleX(1.6f).scaleY(1.6f).setDuration(700).start()
        Handler(Looper.getMainLooper()).postDelayed({ startActivity(li); overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out) }, 650)
    }

    // ---------- usage ----------
    private fun hasUsage(): Boolean {
        val a = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun usage30(): Map<String, Long> {
        val m = HashMap<String, Long>()
        try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            for (u in usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 30L * 86400000L, now)) m[u.packageName] = (m[u.packageName] ?: 0L) + u.totalTimeInForeground
        } catch (e: Exception) {}
        return m
    }

    private fun usageAll(): Map<String, Pair<Long, Long>> {
        val m = HashMap<String, Pair<Long, Long>>()
        try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            for ((k, v) in usm.queryAndAggregateUsageStats(now - 365L * 86400000L, now)) m[k] = Pair(v.totalTimeInForeground, v.lastTimeUsed)
        } catch (e: Exception) {}
        return m
    }

    private fun whenStr(t: Long): String {
        val a = Calendar.getInstance(); val b = Calendar.getInstance(); b.timeInMillis = t
        val diff = (a.get(Calendar.YEAR) * 366 + a.get(Calendar.DAY_OF_YEAR)) - (b.get(Calendar.YEAR) * 366 + b.get(Calendar.DAY_OF_YEAR))
        val hm = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))
        return "Played at $hm " + (if (diff == 0) "today" else if (diff == 1) "yesterday" else SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(t)))
    }

    // ---------- manage ----------
    private fun appCard(items: List<App>, isOn: (App) -> Boolean, change: (App, Boolean) -> Unit): View {
        val c = card()
        items.forEachIndexed { i, a ->
            if (i > 0) c.addView(line(), LinearLayout.LayoutParams(MP, dp(1)).apply { leftMargin = dp(68) })
            val r = lin(false); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(dp(14), dp(10), dp(14), dp(10))
            val iv = ImageView(this); iv.setImageDrawable(a.icon); iv.background = box(10, 0); iv.clipToOutline = true
            r.addView(iv, dp(40), dp(40))
            val n = tv(a.name, 15f, Color.WHITE); n.maxLines = 1
            r.addView(n, LinearLayout.LayoutParams(0, WC, 1f).apply { leftMargin = dp(14) })
            r.addView(sw(isOn(a), true) { on -> change(a, on) })
            c.addView(r)
        }
        return c
    }

    private fun showManage() {
        val page = pageFrame()
        val col = lin(true); col.setPadding(dp(16), dp(34), dp(16), dp(10))
        col.addView(header("Manage"))
        val search = EditText(this); search.hint = "Search for games or apps on this device"; search.textSize = 14f; search.isSingleLine = true
        search.setTextColor(Color.WHITE); search.setHintTextColor(GREY); search.background = box(22, 0xFF262626.toInt()); search.setPadding(dp(18), 0, dp(18), 0)
        col.addView(search, LinearLayout.LayoutParams(MP, dp(44)).apply { topMargin = dp(10) })
        val sv = ScrollView(this); sv.isVerticalScrollBarEnabled = false
        val list = lin(true); sv.addView(list)
        col.addView(sv, LinearLayout.LayoutParams(MP, 0, 1f))
        val apps = queryApps()
        fun build(q: String) {
            list.removeAllViews()
            val rm = prefs.getStringSet("rm", setOf())!!; val man = prefs.getStringSet("m", setOf())!!
            val rec = apps.filter { it.game && it.name.contains(q, true) }
            val oth = apps.filter { !it.game && it.name.contains(q, true) }
            if (rec.isNotEmpty()) {
                list.addView(tv("Recommended games to add  \u00b7  All (${rec.size})", 13f, GREY).apply { setPadding(dp(4), dp(16), 0, dp(8)) })
                list.addView(appCard(rec, { it.pkg !in rm }, { a, on ->
                    val s = HashSet(prefs.getStringSet("rm", emptySet())!!); if (on) s.remove(a.pkg) else s.add(a.pkg)
                    prefs.edit().putStringSet("rm", s).apply()
                }))
            }
            if (oth.isNotEmpty()) {
                list.addView(tv("Other games or apps", 13f, GREY).apply { setPadding(dp(4), dp(16), 0, dp(8)) })
                list.addView(appCard(oth, { it.pkg in man }, { a, on ->
                    val s = HashSet(prefs.getStringSet("m", emptySet())!!); if (on) s.add(a.pkg) else s.remove(a.pkg)
                    prefs.edit().putStringSet("m", s).apply()
                }))
            }
        }
        build("")
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { build(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        page.addView(col, MP, MP); push(page)
    }

    // ---------- performance ----------
    private fun showPerf() {
        perfTab = 0
        val page = pageFrame(); val col = lin(true); col.setPadding(dp(16), dp(34), dp(16), dp(10))
        page.addView(col, MP, MP); buildPerf(col); push(page)
    }

    private fun buildPerf(col: LinearLayout) {
        col.removeAllViews()
        col.addView(header("My gaming performance"))
        val ts = HorizontalScrollView(this); ts.isHorizontalScrollBarEnabled = false
        val tr = lin(false)
        listOf("Performance", "Display", "Controls", "Network settings", "Focus settings").forEachIndexed { i, n ->
            val w = lin(true)
            val t = tv(n, 14f, if (i == perfTab) Color.WHITE else GREY, i == perfTab); t.setPadding(dp(12), dp(14), dp(12), dp(8)); t.isSingleLine = true
            w.addView(t, LinearLayout.LayoutParams(WC, WC))
            val u = View(this); u.setBackgroundColor(if (i == perfTab) Color.WHITE else Color.TRANSPARENT)
            w.addView(u, LinearLayout.LayoutParams(MP, dp(2)))
            w.setOnClickListener { tap(); perfTab = i; buildPerf(col) }
            tr.addView(w, LinearLayout.LayoutParams(WC, WC))
        }
        ts.addView(tr, FrameLayout.LayoutParams(WC, WC)); col.addView(ts, MP, WC)
        val sv = ScrollView(this); sv.isVerticalScrollBarEnabled = false
        val c = lin(true); c.setPadding(0, dp(10), 0, dp(20)); sv.addView(c)
        col.addView(sv, LinearLayout.LayoutParams(MP, 0, 1f))
        val mode = prefs.getInt("ov_mode", 1)
        when (perfTab) {
            0 -> {
                val rc = card(); rc.addView(Radar(this, mode, MODE_COLORS[mode]), MP, dp(150)); c.addView(rc)
                for (i in 0..2) {
                    val m = lin(true); m.setPadding(dp(16), dp(14), dp(16), dp(14))
                    m.background = if (i == mode) box(14, 0xFF1E1E1E.toInt(), 2, MODE_COLORS[i]) else box(14, 0xFF1E1E1E.toInt())
                    m.addView(tv(MODE_NAMES[i], 15f, if (i == mode) MODE_COLORS[i] else Color.WHITE))
                    m.addView(tv(MODE_DESC[i], 12f, if (i == mode) al(MODE_COLORS[i], 190) else GREY))
                    m.setOnClickListener {
                        tap()
                        if (i != mode) {
                            val msg = if (i == 0) "Hyper frame rate, Hyper resolution, and Hyper HDR are unavailable in Power saving mode. Use these features in Balanced or Pro Gamer mode." else if (i == 1) "Balanced mode keeps performance and power consumption in balance." else "Pro Gamer mode will increase your device's power consumption and temperature."
                            confirm("Switch to ${MODE_NAMES[i].replace(" mode", "")} mode?", msg, "Switch") { prefs.edit().putInt("ov_mode", i).apply(); applyAccent(); buildPerf(col) }
                        }
                    }
                    c.addView(m, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) })
                }
                c.addView(tv("With Shizuku on: real Android Game Mode (performance / battery), refresh rate and fixed performance. Without it: only brightness + Do Not Disturb.", 11f, GREY).apply { setPadding(dp(4), dp(12), dp(4), 0) })
            }
            1 -> {
                val a = card()
                a.addView(tv("Screen refresh rate", 15f, Color.WHITE).apply { setPadding(dp(16), dp(14), dp(16), 0) })
                a.addView(tv("High may increase power consumption and temperature. Works only on phones that allow it.", 12f, GREY).apply { setPadding(dp(16), 0, dp(16), dp(6)) })
                a.addView(chips(listOf("Standard" to "Default", "High" to "Max rate"), prefs.getInt("ov_rr", 0), true) { prefs.edit().putInt("ov_rr", it).apply(); buildPerf(col) })
                a.addView(line())
                a.addView(switchRow("Keep screen on", "Screen will not turn off while you play.", prefs.getBoolean("keep_on", false), true) { prefs.edit().putBoolean("keep_on", it).apply() })
                c.addView(a)
            }
            2 -> {
                val a = card(); a.addView(slider("Touch precision")); a.addView(line()); a.addView(slider("Swipe sensitivity")); c.addView(a)
                c.addView(tv("Touch response", 13f, GREY).apply { setPadding(dp(4), dp(16), 0, dp(8)) })
                val b = card(); b.addView(chips(listOf("Standard" to "Save power", "Ultra touch" to "Ultra touch response"), 0, false) {}); c.addView(b)
            }
            3 -> {
                c.addView(tv("Network boost", 13f, GREY).apply { setPadding(dp(4), dp(6), 0, dp(8)) })
                val a = card()
                a.addView(switchRow("Smart dual SIM switch", "Automatically switch between SIM cards to keep gameplay smooth during network lag.", false, false) {})
                a.addView(line())
                a.addView(switchRow("Smart dual-channel network", "Automatically switch between Wi-Fi and mobile networks.", false, false) {})
                c.addView(a)
            }
            else -> {
                c.addView(tv("Call blocker", 13f, GREY).apply { setPadding(dp(4), dp(6), 0, dp(8)) })
                val a = card(); a.addView(switchRow("Call blocker", "Automatically blocks incoming calls and notifications.", false, false) {}); c.addView(a)
                c.addView(tv("Block notifications", 13f, GREY).apply { setPadding(dp(4), dp(16), 0, dp(8)) })
                val b = card()
                b.addView(switchRow("Block notifications", "Notifications will no longer pop up when you're gaming.", prefs.getBoolean("block_notif", false), true) { on ->
                    prefs.edit().putBoolean("block_notif", on).apply()
                    val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                    if (on && !nm.isNotificationPolicyAccessGranted) { toast("Allow Do Not Disturb access"); startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                })
                c.addView(b)
                c.addView(tv("Do Not Disturb", 13f, GREY).apply { setPadding(dp(4), dp(16), 0, dp(8)) })
                val d = card(); d.addView(switchRow("Answer calls on speaker", "Incoming calls answered in Game mode will be put on speaker.", false, false) {}); c.addView(d)
            }
        }
    }

    // ---------- profile ----------
    private fun showProfile() {
        val f = FrameLayout(this); f.isClickable = true
        val sc = View(this); sc.setBackgroundColor(0x99000000.toInt()); sc.setOnClickListener { pop() }
        f.addView(sc, MP, MP)
        val panel = ScrollView(this); panel.setBackgroundColor(0xFF1A1A1A.toInt()); panel.isVerticalScrollBarEnabled = false
        val col = lin(true); col.setPadding(dp(16), dp(34), dp(16), dp(20)); panel.addView(col)
        val nick = prefs.getString("nick", "SeetX Gamer")!!
        val nr = lin(false); nr.gravity = Gravity.CENTER_VERTICAL; nr.setPadding(0, 0, 0, dp(14))
        val av = ImageView(this); av.setImageBitmap(logoBmp); av.background = GradientDrawable().apply { shape = GradientDrawable.OVAL }; av.clipToOutline = true
        nr.addView(av, dp(46), dp(46))
        nr.addView(tv(nick, 16f, Color.WHITE, true), LinearLayout.LayoutParams(0, WC, 1f).apply { leftMargin = dp(12) })
        nr.addView(tv("\u203A", 22f, GREY))
        nr.setOnClickListener {
            tap(); val e = EditText(this); e.setText(nick); e.setSingleLine(true)
            AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle("Nickname").setView(e)
                .setPositiveButton("OK") { _, _ -> val n = e.text.toString().trim(); if (n.isNotEmpty()) { prefs.edit().putString("nick", n).apply(); pop(); showProfile() } }
                .setNegativeButton("Cancel", null).show()
        }
        col.addView(nr)
        val us = if (hasUsage()) usageAll() else null
        val tc = card(); tc.setPadding(dp(16), dp(14), dp(16), dp(10))
        var total = 0L
        for (g in games) total += us?.get(g.pkg)?.first ?: 0L
        val hd = lin(false); hd.addView(tv("Time played", 15f, Color.WHITE)); hd.addView(tv("   " + fmt(total), 13f, GREY)); tc.addView(hd)
        if (us == null) {
            val a = tv("Allow usage access to see play time  \u203A", 13f, accent()); a.setPadding(0, dp(12), 0, dp(4))
            a.setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }; tc.addView(a)
        } else {
            for (g in games.sortedByDescending { us[it.pkg]?.first ?: 0L }.take(2)) {
                val st = us[g.pkg] ?: continue
                if (st.first <= 0) continue
                val r = lin(false); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, dp(10), 0, 0)
                val iv = ImageView(this); iv.setImageBitmap(g.bmp); iv.background = box(9, 0); iv.clipToOutline = true
                r.addView(iv, dp(38), dp(38))
                val t = lin(true); t.addView(tv(g.name, 15f, Color.WHITE)); t.addView(tv(whenStr(st.second) + "  |  " + fmt(st.first), 12f, GREY))
                r.addView(t, LinearLayout.LayoutParams(WC, WC).apply { leftMargin = dp(12) })
                tc.addView(r)
            }
        }
        col.addView(tc)
        val rows = card()
        fun row(t: String, go: () -> Unit) {
            val r = lin(false); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(dp(16), dp(16), dp(16), dp(16))
            r.addView(tv(t, 15f, Color.WHITE), LinearLayout.LayoutParams(0, WC, 1f)); r.addView(tv("\u203A", 20f, GREY))
            r.setOnClickListener { tap(); go() }; rows.addView(r)
        }
        row("Game album") {
            try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Gallery not found") }
        }
        rows.addView(line())
        row("Performance settings") { pop(); showPerf() }
        rows.addView(line())
        row("More settings") { pop(); showSettings() }
        col.addView(rows, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(12) })
        f.addView(panel, FrameLayout.LayoutParams(minOf(dp(380), (resources.displayMetrics.widthPixels * .92f).toInt()), MP, Gravity.START))
        push(f)
    }

    // ---------- settings (about + permissions) ----------
    private val perms = ArrayList<Pair<TextView, () -> Boolean>>()

    private fun refreshPerms() {
        for ((t, ok) in perms) { val on = ok(); t.text = if (on) "ON" else "OFF"; t.setTextColor(if (on) 0xFF4CD964.toInt() else 0xFFFF5252.toInt()) }
    }

    private fun addPerm(c: LinearLayout, name: String, why: String, ok: () -> Boolean, go: () -> Unit) {
        val r = lin(false); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(dp(16), dp(14), dp(16), dp(14))
        val l = lin(true); l.addView(tv(name, 15f, Color.WHITE, true)); l.addView(tv(why, 11f, GREY))
        val st = tv("", 13f, Color.WHITE, true)
        r.addView(l, LinearLayout.LayoutParams(0, WC, 1f)); r.addView(st)
        r.setOnClickListener { tap(); go() }
        if (perms.isNotEmpty()) c.addView(line())
        c.addView(r); perms.add(Pair(st, ok))
    }

    private fun showSettings() {
        val page = pageFrame(); val col = lin(true); col.setPadding(dp(16), dp(34), dp(16), dp(24))
        col.addView(header("Settings"))
        col.addView(label("ABOUT"))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "1.0" }
        val ab = card(); ab.setPadding(dp(18), dp(16), dp(18), dp(8))
        val top = lin(false); top.gravity = Gravity.CENTER_VERTICAL; top.setPadding(0, 0, 0, dp(10))
        val lg = ImageView(this); lg.setImageBitmap(logoBmp); lg.background = box(14, 0); lg.clipToOutline = true
        top.addView(lg, dp(60), dp(60)); top.addView(tv("SeetX", 24f, Color.WHITE, true), LinearLayout.LayoutParams(WC, WC).apply { leftMargin = dp(14) })
        ab.addView(top); ab.addView(line())
        for ((k, v) in listOf("Version" to "v$ver", "Developer" to "Henry")) {
            val r = lin(false); r.setPadding(0, dp(14), 0, dp(14))
            r.addView(tv(k, 15f, GREY), LinearLayout.LayoutParams(0, WC, 1f)); r.addView(tv(v, 15f, Color.WHITE, true)); ab.addView(r)
        }
        col.addView(ab)
        col.addView(label("PERMISSIONS (in-game panel)"))
        val pc = card(); perms.clear()
        addPerm(pc, "Display over other apps", "In-game panel (required)", { Settings.canDrawOverlays(this) }) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        addPerm(pc, "Usage access", "Play time + auto-hide panel", { hasUsage() }) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        addPerm(pc, "Do Not Disturb access", "DND / Silent / block notifications", { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }) { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        addPerm(pc, "Modify system settings", "Brightness, rotation, refresh rate", { Settings.System.canWrite(this) }) { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        addPerm(pc, "Shizuku", "Real game FPS + real Pro Gamer mode", { Sh.ready() }) {
            if (!Sh.alive()) {
                val li = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (li != null) startActivity(li) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api")))
            } else Sh.request()
        }
        col.addView(pc)
        col.addView(tv("Real game FPS and real Pro Gamer need Shizuku: 1) Install Shizuku from Play Store. 2) Developer options > Wireless debugging ON, then in Shizuku tap 'Start via Wireless debugging'. 3) Tap the Shizuku row above and allow SeetX.", 11f, GREY).apply { setPadding(dp(4), dp(12), dp(4), 0) })
        permRefresh = { refreshPerms() }
        refreshPerms()
        val sv = ScrollView(this); sv.isVerticalScrollBarEnabled = false; sv.addView(col)
        page.addView(sv, MP, MP); push(page)
    }
}

private class CubeBg(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var col = 0xFF7ED321.toInt()
    private val t0 = System.nanoTime()
    fun setAccent(c: Int) {
        ValueAnimator.ofObject(ArgbEvaluator(), col, c).apply { duration = 500; addUpdateListener { col = it.animatedValue as Int }; start() }
    }
    private fun face(cv: Canvas, pts: FloatArray, c: Int, a: Int) {
        path.reset(); path.moveTo(pts[0], pts[1]); path.lineTo(pts[2], pts[3]); path.lineTo(pts[4], pts[5]); path.lineTo(pts[6], pts[7]); path.close()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(pts[0], pts[1], pts[4], pts[5], intArrayOf(Color.argb(a / 4, Color.red(c), Color.green(c), Color.blue(c)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawPath(path, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = 8f; p.color = Color.argb(a / 5, Color.red(c), Color.green(c), Color.blue(c)); cv.drawPath(path, p)
        p.strokeWidth = 2.2f; p.color = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)); cv.drawPath(path, p)
    }
    private fun cube(cv: Canvas, cx: Float, cy: Float, s: Float, a: Int) {
        val k = s * .87f; val blue = 0xFF3A8BFF.toInt()
        face(cv, floatArrayOf(cx, cy - s, cx + k, cy - s * .5f, cx, cy, cx - k, cy - s * .5f), col, a)
        face(cv, floatArrayOf(cx - k, cy - s * .5f, cx, cy, cx, cy + s, cx - k, cy + s * .5f), blue, a * 6 / 10)
        face(cv, floatArrayOf(cx, cy, cx + k, cy - s * .5f, cx + k, cy + s * .5f, cx, cy + s), col, a * 8 / 10)
    }
    override fun onDraw(cv: Canvas) {
        cv.drawColor(Color.BLACK)
        val w = width.toFloat(); val h = height.toFloat(); val u = minOf(w, h)
        val t = (System.nanoTime() - t0) / 1e9f
        p.shader = RadialGradient(w * .5f, h * .62f, u * .9f, intArrayOf(Color.argb(40, Color.red(col), Color.green(col), Color.blue(col)), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null
        cube(cv, w * .42f, h * .64f + sin(t * .8f) * u * .012f, u * .34f, 230)
        cube(cv, w * .76f, h * .40f + sin(t * .7f + 1f) * u * .012f, u * .22f, 190)
        cube(cv, w * .16f, h * .52f + sin(t * .9f + 2f) * u * .01f, u * .13f, 150)
        postInvalidateOnAnimation()
    }
}

private class Radar(c: Context, private val mode: Int, private val accent: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density; val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h * .5f
        val heat = floatArrayOf(.25f, .5f, .9f)[mode]; val batt = floatArrayOf(.95f, .65f, .3f)[mode]; val perf = floatArrayOf(.55f, .8f, 1f)[mode]
        val r = h * .36f
        val rect = RectF(cx - r * 2.1f, cy - r, cx + r * 2.1f, cy + r)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5 * d; p.strokeCap = Paint.Cap.ROUND
        p.color = 0x33FFFFFF; cv.drawArc(rect, 150f, 60f, false, p); cv.drawArc(rect, -30f, 60f, false, p)
        p.color = 0xFFFF7A1A.toInt(); cv.drawArc(rect, 150f, 60f * heat, false, p)
        p.color = 0xFF7ED321.toInt(); cv.drawArc(rect, 30f - 60f * batt, 60f * batt, false, p)
        val s = r * (.5f + .4f * perf); val k = s * .87f
        fun sh(f: Float) = Color.rgb((Color.red(accent) * f).toInt().coerceIn(0, 255), (Color.green(accent) * f).toInt().coerceIn(0, 255), (Color.blue(accent) * f).toInt().coerceIn(0, 255))
        fun face(a: FloatArray, c: Int) {
            val q = Path(); q.moveTo(a[0], a[1]); q.lineTo(a[2], a[3]); q.lineTo(a[4], a[5]); q.lineTo(a[6], a[7]); q.close()
            p.style = Paint.Style.FILL; p.color = c; cv.drawPath(q, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = Color.argb(110, 0, 0, 0); cv.drawPath(q, p)
        }
        face(floatArrayOf(cx, cy - s, cx + k, cy - s * .5f, cx, cy, cx - k, cy - s * .5f), sh(1.3f))
        face(floatArrayOf(cx - k, cy - s * .5f, cx, cy, cx, cy + s, cx - k, cy + s * .5f), sh(.6f))
        face(floatArrayOf(cx, cy, cx + k, cy - s * .5f, cx + k, cy + s * .5f, cx, cy + s), sh(.9f))
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER; p.textSize = 10 * d; p.color = 0xFF9A9A9A.toInt(); p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        cv.drawText("Touch control", cx - r * 1.35f, cy - r * .9f, p); cv.drawText("Image quality", cx + r * 1.35f, cy - r * .9f, p)
        cv.drawText("Heating", cx - r * 1.8f, cy + r * .9f, p); cv.drawText("Smoothness", cx, cy + r * 1.2f, p); cv.drawText("Battery", cx + r * 1.8f, cy + r * .9f, p)
    }
}

private class Intro(c: android.content.Context, private val logo: Bitmap) : View(c) {
    private var t0 = 0L
    private var started = false
    var done: (() -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rnd = java.util.Random(3)
    private val px = FloatArray(30) { rnd.nextFloat() }
    private val ps = FloatArray(30) { .06f + rnd.nextFloat() * .12f }
    private val pz = FloatArray(30) { 1.5f + rnd.nextFloat() * 2.5f }
    private val nf = 130
    private val fx = FloatArray(nf) { rnd.nextFloat() }
    private val fs = FloatArray(nf) { .35f + rnd.nextFloat() * .45f }
    private val fp = FloatArray(nf) { rnd.nextFloat() }
    private val fz = FloatArray(nf) { .6f + rnd.nextFloat() * .8f }
    private val fh = FloatArray(nf) { .55f + rnd.nextFloat() * .45f }
    private val fr = RectF()
    private val addP = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val blobs = makeBlobs()
    private fun makeBlobs(): Array<Bitmap> {
        val cols = intArrayOf(0xFFFF9A3C.toInt(), 0xFFFF5A28.toInt(), 0xFFE62A1E.toInt(), 0xFFB81418.toInt(), 0xFF7A0A12.toInt(), 0xFF3A0508.toInt())
        return Array(6) { k ->
            val b = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val c = cols[k]
            val q = Paint(Paint.ANTI_ALIAS_FLAG)
            q.shader = RadialGradient(48f, 48f, 48f, intArrayOf(Color.argb(235, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(110, Color.red(c), Color.green(c), Color.blue(c)), Color.TRANSPARENT), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
            Canvas(b).drawCircle(48f, 48f, 48f, q)
            b
        }
    }
    fun begin() { t0 = System.nanoTime(); started = true; invalidate() }
    fun ready() = started && (System.nanoTime() - t0) / 1e9f >= 4.0f
    private fun cl(v: Float) = v.coerceIn(0f, 1f)
    private fun ease(v: Float) = 1 - (1 - v) * (1 - v) * (1 - v)

    override fun onDraw(cv: Canvas) {
        cv.drawColor(0xFF0A0305.toInt())
        if (!started) return
        val t = (System.nanoTime() - t0) / 1e9f
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2 - h * .03f
        val sz = minOf(w * .42f, h * .58f)
        val T = 2.75f
        val f0 = cl((t - .2f) / 1.8f) * (if (t >= T) 1f else .9f)
        val surge = if (t >= T) 1f + .5f * (1f - cl((t - T) / .8f)) else 1f
        val inten = minOf(f0 * surge, 1.3f); val ic = minOf(inten, 1f)
        val fl = .85f + .15f * sin(t * 9f)
        p.shader = LinearGradient(0f, h, 0f, h * (1f - .6f * ic), intArrayOf(Color.argb((140 * ic * fl).toInt(), 230, 30, 20), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null
        for (i in 0 until nf) {
            val u = (t * fs[i] + fp[i]) % 1f
            val rise = h * (.25f + .55f * inten) * fh[i]
            val y = h * 1.03f - u * rise
            val x = fx[i] * w + sin(t * (2f + fz[i] * 2f) + fp[i] * 6.28f) * w * .012f * (1f + u * 3f)
            val r = h * .09f * fz[i] * (1f - u * .75f) * (.5f + ic * .5f)
            addP.alpha = (255 * (1f - u * u) * ic).toInt().coerceIn(0, 255)
            fr.set(x - r, y - r, x + r, y + r)
            cv.drawBitmap(blobs[(u * 5.99f).toInt()], null, fr, addP)
        }
        val ga = if (t < T) cl((t - 1.2f) / 1.55f) * .55f else .55f + .45f * cl((t - T) / .6f)
        p.shader = RadialGradient(cx, cy, w * .75f, intArrayOf(Color.argb((150 * ga).toInt(), 229, 57, 53), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null
        p.color = 0xFFFF5A4F.toInt()
        val ea = cl((t - .5f) / 1.5f)
        for (i in px.indices) {
            val y = h - ((t * ps[i] + i * .137f) % 1f) * h
            p.alpha = (110 * ea * (y / h)).toInt().coerceIn(0, 255)
            cv.drawCircle(px[i] * w, y, pz[i], p)
        }
        val lu = cl((t - .3f) / .5f); val la = 1f - cl((t - .8f) / .4f)
        if (lu > 0f && la > 0f) {
            val lw = w * .9f * ease(lu)
            p.shader = LinearGradient(0f, cy - 30f, 0f, cy + 30f, intArrayOf(Color.TRANSPARENT, Color.argb((110 * la).toInt(), 229, 57, 53), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            cv.drawRect(cx - lw / 2, cy - 30f, cx + lw / 2, cy + 30f, p); p.shader = null
            p.color = Color.argb((230 * la).toInt(), 255, 255, 255)
            cv.drawRect(cx - lw / 2, cy - 1.5f, cx + lw / 2, cy + 1.5f, p)
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f
        for (j in 0..1) {
            val st = 1.2f + j * .3f; val u = cl((t - st) / (T - st))
            if (u > 0f && u < 1f) {
                p.color = Color.argb((150 * sin(u * 3.14159f)).toInt(), 255, 90, 80)
                cv.drawCircle(cx, cy, sz * (1.8f - 1.25f * u * u), p)
            }
        }
        val ru = cl((t - T) / .8f)
        if (t >= T && ru < 1f) {
            p.strokeWidth = 3f; p.color = Color.argb((160 * (1 - ru)).toInt(), 255, 90, 80)
            cv.drawCircle(cx, cy, sz * (.5f + .7f * ease(ru)), p)
        }
        p.style = Paint.Style.FILL
        if (t >= T) {
            val u = cl((t - T) / .6f)
            val sc = (.82f + .18f * ease(u)) * (1f + .03f * cl((t - 3.3f) / 1.7f))
            val dst = RectF(-sz / 2, -sz / 2, sz / 2, sz / 2)
            cv.save(); cv.translate(cx, cy); cv.scale(sc, sc)
            p.color = Color.WHITE; p.alpha = (255 * cl(u * 3f)).toInt()
            cv.drawBitmap(logo, null, dst, p)
            val st = (t - 3.3f) / .7f
            if (st in 0f..1f) {
                cv.save(); cv.clipRect(dst)
                val bx = -sz + st * sz * 2f
                p.color = Color.WHITE
                p.shader = LinearGradient(bx, -sz / 2, bx + sz * .35f, sz / 2, intArrayOf(Color.TRANSPARENT, 0x55FFFFFF, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
                cv.drawRect(dst, p); p.shader = null
                cv.restore()
            }
            cv.restore()
        }
        val fa = if (t >= T) 1f - cl((t - T) / .3f) else 0f
        if (fa > 0f) { p.color = Color.argb((70 * fa).toInt(), 255, 120, 110); cv.drawRect(0f, 0f, w, h, p) }
        val ta = cl((t - 3.2f) / .8f)
        if (ta > 0f) {
            val ty = cy + sz / 2 + h * .11f
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif", Typeface.BOLD); p.textSize = h * .06f
            p.letterSpacing = .5f - .25f * ease(ta)
            p.color = Color.argb((255 * ta).toInt(), 255, 255, 255)
            cv.drawText("WELCOME", cx, ty, p); p.letterSpacing = 0f
            val lw = h * .1f * ease(ta)
            p.color = Color.argb((255 * ta).toInt(), 229, 57, 53)
            cv.drawRect(cx - lw, ty + 18f, cx + lw, ty + 22f, p)
        }
        if (t >= 4.0f) {
            val ca = cl((t - 4.0f) / .6f) * (.55f + .45f * sin(t * 4f))
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif", Typeface.NORMAL); p.textSize = h * .028f
            p.letterSpacing = .3f; p.color = Color.argb((200 * ca).toInt(), 255, 255, 255)
            cv.drawText("TAP TO CONTINUE", cx, h - h * .07f, p); p.letterSpacing = 0f
        }
        postInvalidateOnAnimation()
    }
}

private class RgbTile(c: android.content.Context, private val rad: Float, private val inset: Float, private val dens: Float) : FrameLayout(c) {
    var on = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val mx = Matrix()
    private var sh: SweepGradient? = null
    init { setWillNotDraw(false); clipChildren = false }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        sh = SweepGradient(w / 2f, h / 2f, intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED), null)
    }
    override fun dispatchDraw(cv: Canvas) {
        super.dispatchDraw(cv)
        val s = sh ?: return
        mx.setRotate((System.nanoTime() / 8_000_000L % 360L).toFloat(), width / 2f, height / 2f)
        s.setLocalMatrix(mx); p.shader = s
        rect.set(inset, inset, width - inset, height - inset)
        val base = if (on) 1f else .7f
        p.strokeWidth = 11f * dens; p.alpha = (45 * base).toInt(); cv.drawRoundRect(rect, rad, rad, p)
        p.strokeWidth = 6f * dens; p.alpha = (90 * base).toInt(); cv.drawRoundRect(rect, rad, rad, p)
        p.strokeWidth = (if (on) 3f else 2f) * dens; p.alpha = (255 * base).toInt(); cv.drawRoundRect(rect, rad, rad, p)
        postInvalidateOnAnimation()
    }
}
