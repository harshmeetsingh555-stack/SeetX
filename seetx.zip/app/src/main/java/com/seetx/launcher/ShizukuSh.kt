package com.seetx.launcher

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Sh {
    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun ready(): Boolean = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    fun request() { try { Shizuku.requestPermission(100) } catch (e: Throwable) {} }
    fun run(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as java.lang.Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Throwable) { "" }
}
