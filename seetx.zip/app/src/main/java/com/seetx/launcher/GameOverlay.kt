package com.seetx.launcher

import android.app.ActivityManager
import android.app.ActivityOptions
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

class GameOverlayService : Service() {
    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("seetx", 0) }
    private var handleView: View? = null
    private var panelRoot: FrameLayout? = null
    private var gamePkg = ""
    private var gameName = ""
    private var games: List<String> = emptyList()
    private var mode = 1
    private var tab = 0
    private var prevTab = 0
    private var started = false
    private var t0 = 0L
    private var tick = 0
    private var origB = 128
    private var origBM = 0
    private var origRot = 1
    private var origRinger = AudioManager.RINGER_MODE_NORMAL
    private var origFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var rrChanged = false
    private var batt = 0
    private var tempC = 0f
    private var skinC = -1f
    private var gameFps = -1
    private var layerName = ""
    private var realRun = false
    private var origRead = false
    private var origPeak = ""
    private var origMin = ""
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var capThread: HandlerThread? = null
    private val capFrames = java.util.concurrent.atomic.AtomicInteger(0)
    private var capOn = false
    private var capWarm = false
    private var capFps = -1
    private var refreshSaved = false
    private var origMinF = -1f
    private var origPeakF = -1f
    private var maxHzSaved = 60f
    private var ping = -1f
    private var fps = 0
    private var fpsOn = false
    private var fpsFrames = 0
    private var fpsLast = 0L
    private var ringFps: Ring? = null
    private var ringNet: Ring? = null
    private var tvBatt: TextView? = null
    private var tvNetH: TextView? = null
    private var tvFpsH: TextView? = null
    private var tvTempH: TextView? = null
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val MODE_NAMES = arrayOf("Power-saving", "Balanced", "Pro Gamer")
    private val MODE_COLORS = intArrayOf(0xFF35C8FF.toInt(), 0xFF7ED321.toInt(), 0xFFFF5A00.toInt())
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        gamePkg = i.getStringExtra("pkg") ?: ""
        gameName = i.getStringExtra("name") ?: ""
        games = i.getStringArrayListExtra("games") ?: arrayListOf()
        val pc = i.getIntExtra("pcode", 0)
        val pd: Intent? = i.getParcelableExtra("pdata")
        val proj = pc != 0 && pd != null && !capOn
        startFg(proj)
        if (started) return START_NOT_STICKY
        started = true
        t0 = SystemClock.elapsedRealtime()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        saveOriginals()
        mode = prefs.getInt("ov_mode", 1)
        applyMode(mode)
        applyReal(mode)
        if (prefs.getInt("ov_rr", 0) == 1) setRefresh(true)
        addHandle()
        if (proj && pd != null) startCapture(pc, pd)
        h.post(ticker)
        return START_NOT_STICKY
    }

    private fun startFg(proj: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ov", "Game Assistant", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "ov").setContentTitle("SeetX Game Assistant").setContentText(gameName)
            .setSmallIcon(android.R.drawable.ic_menu_manage).build()
        var type = 0
        if (Build.VERSION.SDK_INT >= 34) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        if (proj && Build.VERSION.SDK_INT >= 29) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (Build.VERSION.SDK_INT >= 29 && type != 0) startForeground(1, n, type) else startForeground(1, n)
    }

    private fun saveOriginals() {
        try {
            origB = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            origBM = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
            origRot = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
        } catch (e: Exception) {}
        origRinger = (getSystemService(AUDIO_SERVICE) as AudioManager).ringerMode
        origFilter = (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).currentInterruptionFilter
        if (origFilter < 1) origFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    }

    private fun restore() {
        if (!started) return
        restoreReal()
        try {
            if (Settings.System.canWrite(this)) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, origBM)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, origB)
                Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, origRot)
                if (rrChanged) restoreRefresh()
            }
        } catch (e: Exception) {}
        try { (getSystemService(AUDIO_SERVICE) as AudioManager).ringerMode = origRinger } catch (e: Exception) {}
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(origFilter)
        } catch (e: Exception) {}
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        fpsOn = false; realRun = false
        stopCapture()
        if (started) {
            closePanel()
            try { handleView?.let { wm.removeView(it) } } catch (e: Exception) {}
            handleView = null
            restore()
        }
        super.onDestroy()
    }

    // ---------- live data ----------
    private val ticker = object : Runnable {
        override fun run() {
            readBattery()
            if (tick++ % 3 == 0) doPing()
            checkForeground()
            if (capOn && panelRoot != null) { val c = capFrames.getAndSet(0); if (capWarm) capFps = c else capWarm = true }
            updateLive()
            h.postDelayed(this, 1000)
        }
    }

    private val fpsCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!fpsOn) return
            fpsFrames++
            if (fpsLast == 0L) fpsLast = ns
            if (ns - fpsLast >= 500_000_000L) { fps = (fpsFrames * 1e9 / (ns - fpsLast)).toInt(); fpsFrames = 0; fpsLast = ns }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun readBattery() {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        batt = l * 100 / maxOf(s, 1); tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
    }

    private fun doPing() {
        thread {
            val a = System.nanoTime()
            val r = try { Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }; (System.nanoTime() - a) / 1e6f } catch (e: Exception) { -1f }
            h.post { ping = r }
        }
    }

    private fun hasUsage(): Boolean {
        val a = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun checkForeground() {
        if (SystemClock.elapsedRealtime() - t0 < 8000 || !hasUsage()) return
        try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = usm.queryEvents(now - 15000, now); val e = UsageEvents.Event(); var last = ""
            while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName }
            if (last.isEmpty()) return
            if (last == packageName) { stopSelf(); return }
            val inGame = last == gamePkg
            handleView?.visibility = if (inGame && panelRoot == null) View.VISIBLE else View.GONE
            if (!inGame) closePanel()
        } catch (e: Exception) {}
    }

    private fun updateLive() {
        val ff = if (capOn && capFps >= 0) capFps else if (Sh.ready() && gameFps >= 0) gameFps else fps
        ringFps?.set(ff.toString(), (ff / 120f).coerceIn(0f, 1f))
        ringNet?.set(if (ping >= 0) "%.1f".format(ping) else "--", if (ping >= 0) (1f - ping / 150f).coerceIn(.05f, 1f) else 0f)
        tvBatt?.text = "$batt%"
        tvNetH?.text = if (ping >= 0) "%.1f ms".format(ping) else "-- ms"
        tvFpsH?.text = "$ff fps"
        tvTempH?.text = "%.0f \u00b0C".format(if (skinC > 0) skinC else tempC)
    }

    // ---------- windows ----------
    private fun lp(w: Int, hh: Int, flags: Int) = WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)

    private fun addHandle() {
        val bar = View(this); bar.background = box(3, 0xCCFFFFFF.toInt())
        val boxV = FrameLayout(this)
        boxV.addView(bar, FrameLayout.LayoutParams(dp(4), dp(46), Gravity.END or Gravity.CENTER_VERTICAL))
        var sx = 0f; var done = false
        boxV.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; done = false }
                MotionEvent.ACTION_MOVE -> if (!done && Math.abs(ev.rawX - sx) >= dp(26)) { done = true; openPanel() }
            }
            true
        }
        val p = lp(dp(24), dp(80), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or (if (prefs.getBoolean("keep_on", false)) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0))
        p.gravity = Gravity.END or Gravity.TOP; p.x = 0; p.y = dp(6)
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        handleView = boxV
        wm.addView(boxV, p)
    }

    private fun openPanel() {
        if (panelRoot != null) return
        val root = FrameLayout(this)
        buildInto(root)
        wm.addView(root, lp(MP, MP, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS))
        panelRoot = root
        handleView?.visibility = View.GONE
        root.alpha = 0f; root.animate().alpha(1f).setDuration(180).start()
        root.getChildAt(1)?.let { it.translationX = dp(60).toFloat(); it.animate().translationX(0f).setDuration(220).start() }
        fpsOn = true; fpsFrames = 0; fpsLast = 0L
        Choreographer.getInstance().postFrameCallback(fpsCb)
        startReal()
        capActive(true)
    }

    private fun closePanel() {
        val r = panelRoot ?: return
        panelRoot = null; fpsOn = false; realRun = false
        capActive(false)
        try { wm.removeView(r) } catch (e: Exception) {}
        ringFps = null; ringNet = null; tvBatt = null; tvNetH = null; tvFpsH = null; tvTempH = null
        handleView?.visibility = View.VISIBLE
    }

    private fun fill() { panelRoot?.let { it.removeAllViews(); buildInto(it) } }

    // ---------- ui helpers ----------
    private fun box(r: Int, c: Int, stroke: Int = 0, sc: Int = 0): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(c); if (stroke > 0) setStroke(dp(stroke), sc)
    }
    private fun lin(v: Boolean): LinearLayout = LinearLayout(this).apply { orientation = if (v) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
    private fun tv(t: String, sp: Float, c: Int, bold: Boolean = false, g: Int = Gravity.START): TextView = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); gravity = g
        typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun open(i: Intent) { try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) } catch (e: Exception) {} }
    private fun fmt(ms: Long): String { val m = ms / 60000; return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min" }
    private fun ago(t: Long): String {
        val m = (System.currentTimeMillis() - t) / 60000
        return if (m < 1) "just now" else if (m < 60) "$m min ago" else if (m < 1440) "${m / 60} h ago" else "${m / 1440} d ago"
    }

    private fun buildInto(root: FrameLayout) {
        val accent = MODE_COLORS[mode]
        val scrim = View(this); scrim.setBackgroundColor(0x66000000); scrim.setOnClickListener { closePanel() }
        root.addView(scrim, FrameLayout.LayoutParams(MP, MP))
        val wrap = lin(false); wrap.setPadding(0, dp(12), dp(12), dp(12))
        val rail = lin(true); rail.gravity = Gravity.CENTER_HORIZONTAL; rail.setPadding(dp(4), dp(10), dp(4), dp(10)); rail.background = box(36, 0xF2161618.toInt())
        rail.addView(tabBtn("Performance", 0, accent)); rail.addView(tabBtn("Tools", 1, accent)); rail.addView(tabBtn("Me", 2, accent))
        val line = View(this); line.setBackgroundColor(0x33FFFFFF)
        rail.addView(line, LinearLayout.LayoutParams(dp(40), dp(1)).apply { topMargin = dp(6); bottomMargin = dp(10) })
        val pm = packageManager
        for (pk in shortcuts()) {
            val iv = ImageView(this)
            try { iv.setImageDrawable(pm.getApplicationIcon(pk)) } catch (e: Exception) { continue }
            iv.background = box(24, 0); iv.clipToOutline = true
            iv.setOnClickListener { openFloating(pk) }
            rail.addView(iv, LinearLayout.LayoutParams(dp(46), dp(46)).apply { bottomMargin = dp(10) })
        }
        val plus = tv("+", 24f, Color.WHITE, false, Gravity.CENTER); plus.background = box(24, 0xFF2E2E30.toInt())
        plus.setOnClickListener { prevTab = tab; tab = 3; fill() }
        rail.addView(plus, LinearLayout.LayoutParams(dp(46), dp(46)).apply { bottomMargin = dp(10) })
        val railScroll = ScrollView(this); railScroll.isVerticalScrollBarEnabled = false; railScroll.addView(rail)
        val body = ScrollView(this); body.isVerticalScrollBarEnabled = false; body.background = box(28, 0xF2161618.toInt())
        body.addView(when (tab) { 0 -> perfPage(accent); 1 -> toolsPage(accent); 3 -> pickerPage(accent); else -> mePage(accent) })
        wrap.addView(body, LinearLayout.LayoutParams(dp(330), MP))
        wrap.addView(railScroll, LinearLayout.LayoutParams(dp(82), MP).apply { leftMargin = dp(10) })
        root.addView(wrap, FrameLayout.LayoutParams(WC, MP, Gravity.END))
        updateLive()
    }

    private fun tabBtn(label: String, idx: Int, accent: Int): View {
        val c = lin(true); c.gravity = Gravity.CENTER_HORIZONTAL; c.setPadding(0, dp(10), 0, dp(10))
        val col = if (tab == idx) accent else 0xFF9A9A9A.toInt()
        c.addView(TabIcon(this, idx, col), dp(30), dp(30))
        c.addView(tv(label, 11f, col, false, Gravity.CENTER))
        c.setOnClickListener { tab = idx; fill() }
        return c
    }

    private fun perfPage(accent: Int): LinearLayout {
        val p = lin(true); p.setPadding(dp(16), dp(14), dp(16), dp(14))
        val t = tv("SEETX BOOST", 12f, 0xFFCCCCCC.toInt(), true, Gravity.CENTER); t.letterSpacing = .15f
        p.addView(t, MP, WC)
        val rings = lin(false); rings.gravity = Gravity.CENTER_VERTICAL
        ringFps = Ring(this, accent, if (capOn || Sh.ready()) "Frame rate" else "Display", "fps"); ringNet = Ring(this, accent, "Network", "ms")
        val mid = lin(true); mid.gravity = Gravity.CENTER
        tvBatt = tv("$batt%", 18f, Color.WHITE, true, Gravity.CENTER)
        mid.addView(tv("Battery", 11f, 0xFFBBBBBB.toInt(), false, Gravity.CENTER)); mid.addView(tvBatt)
        rings.addView(ringFps, dp(108), dp(108)); rings.addView(mid, LinearLayout.LayoutParams(0, WC, 1f)); rings.addView(ringNet, dp(108), dp(108))
        p.addView(rings, MP, WC)
        p.addView(tv(if (capOn) "Live FPS (screen capture)" else if (Sh.ready()) "Live game FPS (Shizuku)" else "Display rate only. Turn on Real FPS in SeetX Settings.", 10f, 0xFF888888.toInt(), false, Gravity.CENTER), MP, WC)
        val seg = lin(false); seg.background = box(24, 0xFF222224.toInt()); seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        for (i in 0..2) {
            val b = tv(MODE_NAMES[i], 12f, if (i == mode) Color.WHITE else 0xFFBBBBBB.toInt(), i == mode, Gravity.CENTER)
            b.setPadding(dp(2), dp(11), dp(2), dp(11))
            if (i == mode) b.background = box(22, accent)
            b.setOnClickListener { setMode(i) }
            seg.addView(b, LinearLayout.LayoutParams(0, WC, 1f))
        }
        p.addView(seg, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(14) })
        p.addView(tv("Screen refresh rate", 15f, Color.WHITE), LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(18) })
        p.addView(tv("High may increase power use and temperature.", 11f, 0xFF888888.toInt()))
        val rr = prefs.getInt("ov_rr", 0)
        val chips = lin(false)
        for ((i, n) in listOf("Standard", "High").withIndex()) {
            val c = tv(n, 14f, if (i == rr) accent else 0xFFBBBBBB.toInt(), false, Gravity.CENTER)
            c.setPadding(0, dp(14), 0, dp(14))
            c.background = if (i == rr) box(14, 0xFF1C1C1E.toInt(), 2, accent) else box(14, 0xFF222224.toInt())
            c.setOnClickListener { setRefresh(i == 1); fill() }
            chips.addView(c, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        p.addView(chips, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) })
        return p
    }

    private fun tool(emoji: String, label: String, on: Boolean, accent: Int, click: () -> Unit): View {
        val c = lin(true); c.gravity = Gravity.CENTER; c.setPadding(dp(4), dp(12), dp(4), dp(12))
        c.background = box(16, if (on) Color.argb(60, Color.red(accent), Color.green(accent), Color.blue(accent)) else 0xFF222224.toInt(), if (on) 2 else 0, accent)
        c.addView(tv(emoji, 22f, Color.WHITE, false, Gravity.CENTER))
        c.addView(tv(label, 11f, if (on) accent else 0xFFCCCCCC.toInt(), false, Gravity.CENTER))
        c.setOnClickListener { click() }
        return c
    }

    private fun toolsPage(accent: Int): LinearLayout {
        val p = lin(true); p.setPadding(dp(16), dp(14), dp(16), dp(14))
        val hd = lin(false)
        tvNetH = tv("-- ms", 12f, accent); tvFpsH = tv("-- fps", 12f, accent, false, Gravity.CENTER); tvTempH = tv("-- \u00b0C", 12f, accent, false, Gravity.END)
        for ((i, pair) in listOf("Network" to tvNetH!!, (if (capOn || Sh.ready()) "Frame rate" else "Display") to tvFpsH!!, "Temperature" to tvTempH!!).withIndex()) {
            val c = lin(true); c.addView(tv(pair.first, 11f, 0xFFDDDDDD.toInt(), false, if (i == 0) Gravity.START else if (i == 1) Gravity.CENTER else Gravity.END)); c.addView(pair.second)
            hd.addView(c, LinearLayout.LayoutParams(0, WC, 1f))
        }
        p.addView(hd, MP, WC)
        val sb = SeekBar(this); sb.max = 255
        sb.progress = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }
        sb.progressTintList = ColorStateList.valueOf(accent); sb.thumbTintList = ColorStateList.valueOf(accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { if (u) setBrightness(v) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(tv("\u2600  Brightness", 12f, 0xFFDDDDDD.toInt()), LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(14) })
        p.addView(sb, MP, WC)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val au = getSystemService(AUDIO_SERVICE) as AudioManager
        val dnd = nm.currentInterruptionFilter > 1
        val rot = try { Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0 } catch (e: Exception) { false }
        val sil = au.ringerMode == AudioManager.RINGER_MODE_SILENT
        val tiles = listOf(
            tool("\uD83D\uDD15", "Do Not Disturb", dnd, accent) {
                if (!nm.isNotificationPolicyAccessGranted) { toast("Allow DND access"); open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                else { try { nm.setInterruptionFilter(if (dnd) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY) } catch (e: Exception) {}; fill() }
            },
            tool("\uD83D\uDD12", "Orientation lock", rot, accent) {
                if (!Settings.System.canWrite(this)) { toast("Allow 'Modify system settings'") }
                else { try { Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (rot) 1 else 0) } catch (e: Exception) {}; fill() }
            },
            tool("\uD83D\uDD07", "Silent", sil, accent) {
                try { au.ringerMode = if (sil) AudioManager.RINGER_MODE_NORMAL else AudioManager.RINGER_MODE_SILENT } catch (e: Exception) { toast("Allow DND access"); open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                fill()
            },
            tool("\uD83D\uDCF6", "WLAN", false, accent) {
                closePanel()
                open(Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS))
            },
            tool("\uD83E\uDDF9", "Cleanup", false, accent) { cleanup() }
        )
        var row: LinearLayout? = null
        for (i in 0 until 6) {
            if (i % 3 == 0) { row = lin(false); p.addView(row, LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) }) }
            val v = if (i < tiles.size) tiles[i] else View(this)
            row!!.addView(v, LinearLayout.LayoutParams(0, WC, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        return p
    }

    private fun usage(): Map<String, Pair<Long, Long>> {
        val m = HashMap<String, Pair<Long, Long>>()
        try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            for ((k, v) in usm.queryAndAggregateUsageStats(now - 365L * 86400000L, now)) m[k] = Pair(v.totalTimeInForeground, v.lastTimeUsed)
        } catch (e: Exception) {}
        return m
    }

    private fun mePage(accent: Int): LinearLayout {
        val p = lin(true); p.setPadding(dp(14), dp(14), dp(14), dp(14))
        val us = if (hasUsage()) usage() else null
        val card = lin(true); card.setPadding(dp(16), dp(14), dp(16), dp(14)); card.background = box(18, 0xFF222224.toInt())
        var total = 0L
        for (g in games) total += us?.get(g)?.first ?: 0L
        val hd = lin(false)
        hd.addView(tv("Time played", 15f, Color.WHITE, true)); hd.addView(tv("   " + fmt(total), 13f, 0xFF999999.toInt()))
        card.addView(hd)
        val pm = packageManager
        for (g in games) {
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(g, 0)).toString() } catch (e: Exception) { g }
            val row = lin(false); row.gravity = Gravity.CENTER_VERTICAL; row.setPadding(0, dp(10), 0, 0)
            val iv = ImageView(this)
            try { iv.setImageDrawable(pm.getApplicationIcon(g)) } catch (e: Exception) {}
            iv.background = box(10, 0); iv.clipToOutline = true
            val col = lin(true)
            val st = us?.get(g)
            col.addView(tv(label, 14f, Color.WHITE, true))
            col.addView(tv(if (st != null && st.first > 0) ago(st.second) + "  |  " + fmt(st.first) else "No data yet", 12f, 0xFF999999.toInt()))
            row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
            row.addView(col, LinearLayout.LayoutParams(WC, WC).apply { leftMargin = dp(12) })
            card.addView(row)
        }
        p.addView(card)
        if (us == null) {
            val b = tv("Allow usage access to see play time  \u203A", 13f, accent)
            b.setPadding(dp(4), dp(14), 0, 0)
            b.setOnClickListener { closePanel(); open(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            p.addView(b)
        }
        val n = prefs.getInt("n_all", 0)
        p.addView(tv("Games launched via SeetX: $n", 12f, 0xFF999999.toInt()), LinearLayout.LayoutParams(WC, WC).apply { topMargin = dp(14) })
        return p
    }

    // ---------- actions ----------
    private fun setMode(i: Int) {
        mode = i; prefs.edit().putInt("ov_mode", i).apply()
        applyMode(i)
        applyReal(i)
        fill()
    }

    private fun applyMode(i: Int) {
        if (Settings.System.canWrite(this)) {
            try {
                if (i == 0) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 70)
                } else {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, origBM)
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, origB)
                }
            } catch (e: Exception) {}
            setRefreshMode(i)
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            try { nm.setInterruptionFilter(if (i == 2 || prefs.getBoolean("block_notif", false)) NotificationManager.INTERRUPTION_FILTER_PRIORITY else origFilter) } catch (e: Exception) {}
        }
        if (i == 2) thread { killBg() }
    }

    private fun killBg(): Int {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pk = packageManager.queryIntentActivities(q, 0).map { it.activityInfo.packageName }.distinct().filter { it != gamePkg && it != packageName }
        for (x in pk) { try { am.killBackgroundProcesses(x) } catch (e: Exception) {} }
        return pk.size
    }

    private fun setBrightness(v: Int) {
        if (!Settings.System.canWrite(this)) { toast("Allow 'Modify system settings'"); return }
        try {
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, v.coerceIn(1, 255))
        } catch (e: Exception) {}
    }

    private fun setRefresh(hi: Boolean) {
        prefs.edit().putInt("ov_rr", if (hi) 1 else 0).apply()
        if (!Settings.System.canWrite(this)) { toast("Allow 'Modify system settings'"); return }
        setRefreshMode(if (hi) 2 else 1)
    }

    private fun setRefreshMode(i: Int) {
        try {
            @Suppress("DEPRECATION")
            val maxHz = wm.defaultDisplay.supportedModes.maxOf { it.refreshRate }
            val cr = contentResolver
            if (!refreshSaved) {
                origMinF = Settings.System.getFloat(cr, "min_refresh_rate", -1f)
                origPeakF = Settings.System.getFloat(cr, "peak_refresh_rate", -1f)
                maxHzSaved = maxHz; refreshSaved = true
            }
            when (i) {
                2 -> { Settings.System.putFloat(cr, "min_refresh_rate", maxHz); Settings.System.putFloat(cr, "peak_refresh_rate", maxHz) }
                0 -> { Settings.System.putFloat(cr, "min_refresh_rate", 0f); Settings.System.putFloat(cr, "peak_refresh_rate", 60f) }
                else -> { Settings.System.putFloat(cr, "min_refresh_rate", if (origMinF >= 0) origMinF else 0f); Settings.System.putFloat(cr, "peak_refresh_rate", if (origPeakF >= 0) origPeakF else maxHz) }
            }
            rrChanged = true
        } catch (e: Exception) {}
    }

    private fun restoreRefresh() {
        if (!refreshSaved) return
        try {
            Settings.System.putFloat(contentResolver, "min_refresh_rate", if (origMinF >= 0) origMinF else 0f)
            Settings.System.putFloat(contentResolver, "peak_refresh_rate", if (origPeakF >= 0) origPeakF else maxHzSaved)
        } catch (e: Exception) {}
    }

    // ---------- real FPS via screen capture (no Shizuku) ----------
    private fun startCapture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data) ?: return
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { h.post { capOn = false; capFps = -1 } }
            }, h)
            val dm = resources.displayMetrics
            val sw = maxOf(64, dm.widthPixels / 12); val sh = maxOf(64, dm.heightPixels / 12)
            val ht = HandlerThread("seetx-cap"); ht.start(); capThread = ht
            val rd = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
            rd.setOnImageAvailableListener({ r ->
                try { r.acquireLatestImage()?.close() } catch (e: Exception) {}
                capFrames.incrementAndGet()
            }, Handler(ht.looper))
            reader = rd
            vd = mp.createVirtualDisplay("seetx_fps", sw, sh, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null)
            capOn = true
        } catch (e: Exception) { capOn = false }
    }

    private fun capActive(on: Boolean) {
        if (!capOn) return
        try { vd?.setSurface(if (on) reader?.surface else null) } catch (e: Exception) {}
        capFrames.set(0); capWarm = false; capFps = -1
    }

    private fun stopCapture() {
        try { vd?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { projection?.stop() } catch (e: Exception) {}
        try { capThread?.quitSafely() } catch (e: Exception) {}
        vd = null; reader = null; projection = null; capThread = null; capOn = false
    }

    private fun cleanup() {
        if (Sh.ready()) { thread { Sh.run("am kill-all") }; toast("Cleanup done"); return }
        thread { val n = killBg(); h.post { toast("Cleanup done ($n apps)") } }
    }
}

private class Ring(c: Context, private val accent: Int, private val label: String, private val unit: String) : View(c) {
    private var value = "--"
    private var frac = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun set(v: String, f: Float) { value = v; frac = f; invalidate() }
    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat(); val cx = w / 2; val cy = height / 2f; val r = w / 2 - 8 * d
        p.style = Paint.Style.FILL; p.color = 0xFF1E1E20.toInt(); cv.drawCircle(cx, cy, r - 6 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5 * d; p.strokeCap = Paint.Cap.ROUND
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        p.color = 0x33FFFFFF; cv.drawArc(rect, 135f, 270f, false, p)
        p.color = accent; cv.drawArc(rect, 135f, 270f * frac.coerceIn(0f, 1f), false, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        p.color = 0xFFDDDDDD.toInt(); p.textSize = 11 * d; cv.drawText(label, cx, cy - 18 * d, p)
        p.typeface = Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
        p.color = Color.WHITE; p.textSize = 28 * d; cv.drawText(value, cx, cy + 12 * d, p)
        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        p.color = 0xFF999999.toInt(); p.textSize = 11 * d; cv.drawText(unit, cx, cy + 30 * d, p)
    }
}

private class TabIcon(c: Context, private val kind: Int, private val col: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); p.color = col
        when (kind) {
            0 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = w * .12f; p.strokeCap = Paint.Cap.ROUND
                cv.drawArc(RectF(w * .1f, h * .1f, w * .9f, h * .9f), 140f, 260f, false, p)
                p.style = Paint.Style.FILL
                val path = Path(); path.moveTo(w * .5f, h * .32f); path.lineTo(w * .58f, h * .62f); path.lineTo(w * .42f, h * .62f); path.close()
                cv.drawPath(path, p)
            }
            1 -> {
                p.style = Paint.Style.FILL; val s = w * .38f; val g = w * .12f
                for (a in 0..1) for (b in 0..1) {
                    val l = w * .06f + a * (s + g); val t = h * .06f + b * (s + g)
                    cv.drawRoundRect(RectF(l, t, l + s, t + s), 6f, 6f, p)
                }
            }
            else -> {
                p.style = Paint.Style.FILL
                cv.drawCircle(w * .5f, h * .3f, w * .2f, p)
                cv.drawArc(RectF(w * .12f, h * .55f, w * .88f, h * 1.3f), 180f, 180f, true, p)
            }
        }
    }
}
